from django.apps import AppConfig


class PerfisConfig(AppConfig):
    name = 'perfis'
