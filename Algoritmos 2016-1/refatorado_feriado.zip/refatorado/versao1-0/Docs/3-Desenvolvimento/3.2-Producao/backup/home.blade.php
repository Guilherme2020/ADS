<!DOCTYPE html>
<html>
<head>
	<title>Sistema Certificado</title>
	<link href="css/app.css" rel="stylesheet">
	<link rel="stylesheet" href="css/custom.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.6/flatly/bootstrap.min.css">

</head>
<body>
	@extends('layout.principal')
	@section('conteudo')



		<p>Aqui Jaz o Sistema</p>

		<p>Cadastre Seu Usuario - Gerente no formulario abaixo </p>

		<form action="" method="POST">

			<input type="hidden" name="_token" value="{{ csrf_token() }}" />


			<div class="form-group">
				<label>Nome</label>
				<input  name="" class="form-control" required>
			</div>

			<div class="form-group">
				<label>Matricula</label>
				<input name = "" class="form-control"required>
			</div>

			<div class="form-group">
				<label>Senha</label>
				<input  name = "" class="form-control" required>
			</div>

			<div class="form-group">
				<label>Cpf</label>
				<input name = "" type="number" class="form-control"required>
			</div>

			<button type="submit" class="btn btn-primary btn-block">Adicionar</button>


		</form>

	@stop		



</body>
</html>