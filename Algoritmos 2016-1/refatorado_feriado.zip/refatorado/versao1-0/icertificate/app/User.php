<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable{
    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'matricula', 'email', 'password',
        'nome', 'cpf', 'rg', 'tipo', 'remember_token'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function setPasswordAttribute($value){
        $this->attributes['password'] = $value;
    }

    public function setNomeAttribute($value){
        $this->attributes['nome'] = strtoupper($value);    
    }

    public function getNomeAttribute($value){
        return ucwords(strtolower($value));    
    }
}
