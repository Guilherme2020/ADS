<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Frequencia extends Model{

    protected $fillable = ['evento_id','inscricao_id', 'descricao', 'data'];

}
?>

