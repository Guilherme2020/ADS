<?php
namespace App;
use Carbon\Carbon;

class ModelHelper{

    public static function getDocumentVar($var){

    }

}
?>

