<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Livro extends Model{

    protected $fillable = ['numero','endereco'];

}
?>

