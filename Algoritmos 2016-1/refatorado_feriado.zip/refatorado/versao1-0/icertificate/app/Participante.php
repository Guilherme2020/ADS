<?php 
	namespace App;
	use Illuminate\Database\Eloquent\Model;
	
	class Participante extends Model{

		public $timestamps = false;
		protected $fillable = ['matricula','nome','cpf','email'];

		public function setNomeAttribute($value){
			$this->attributes['nome'] = strtoupper($value);
		}

		public function getCpfAttribute($value){
			//if(strlen($value) == 11){
			//return 'A';
			//$value = str_split($value, 3);
			//$value = sprintf("%s.%s.%s-%s", $value[0], $value[1], $value[2], $value[3]);
			//}
			return $value;
			//$this->attributes['nome'] = strtoupper($value);
		}

		public function inscricaos(){
        	return $this->hasMany('App\Inscricao');
    	}
	}
 ?>

