<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Evento extends Model{

    public $timestamps = false;
    protected $fillable = ['nome','status','data_inicio', 'data_fim', 'user_id','slug', 'carga_horaria','qtd_vagas', 'qtd_vagas_atual',
        'nome_superior', 'cargo_superior', 'nome_responsavel', 'cargo_responsavel', 'modalidade'];

    public function setNomeAttribute($value){
        $this->attributes['nome'] = $value;
        $this->attributes['slug'] = str_slug($value);
    }    

    public function getDataInicioAttribute($value){
    	return Carbon::parse($value)->format('d/m/Y');
    }

    public function getDataFimAttribute($value){
        return Carbon::parse($value)->format('d/m/Y');
    }

    public function getLocaldoEvento(){
        #
    }



    public function setDataInicioAttribute($value){
        $this->attributes['data_inicio'] = $this->formDataEvento($value);
    }

    public function setDataFimAttribute($value){
        $this->attributes['data_fim'] = $this->formDataEvento($value);
    }

    public function formDataEvento($value){
    #    return Carbon::parse($value)->format('d/m/Y');
         #return  date("Y-m-d", strtotime($value));
         $date = str_replace('/', '-', $value);
         return  date('Y-m-d', strtotime($date));
    }

    //Relacionamentos:
    public function frequencias(){
        return $this->hasMany('App\Frequencia');
    }
    
    public function inscricaos(){
        return $this->hasMany('App\Inscricao');
    }

    public function getParticipantes($array){

    }

}
?>

