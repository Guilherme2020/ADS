<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Certificado extends Model{

    protected $fillable = ['livro_id','inscricao_id', 'codigo', 'carga_horaria', 'endereco'];

}
?>

