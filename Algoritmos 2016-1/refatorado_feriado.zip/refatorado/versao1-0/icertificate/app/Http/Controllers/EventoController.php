<?php
/**
 * Created by PhpStorm.
 * User: grodrigues
 * Date: 19/04/16
 * Time: 01:21
 */

namespace App\Http\Controllers;

use App\Evento;
use App\Http\Requests\EventoRequest;
use App\Http\Requests\ParticipanteRequest;
use App\Participante;
use App\User;
use App\Inscricao;
use App\Configuracao;
use Illuminate\Support\Facades\DB;
use App\Http\helpers;
use Auth;
use PDF;

class EventoController extends BaseController{

    public $url = "evento/cadastro/";

    public function __construct(){
        parent::__construct();
        $this->middleware('auth');
        //, ['except' => ['cadastro']]);
    }

    public function add(){
        $users = User::where('tipo', 'C')->get();
        $usuario = [];
        foreach ($users as $key => $value) {
            $usuario[$value->id] = $value->nome.' - '.$value->matricula;
        }

        return view('evento.add', compact('usuario'));
    }

    public function save(EventoRequest $request){
        $dados = $request->all();
        if(Auth::user()->tipo == 'C')
            $dados['user_id'] = Auth::user()->id;
        // Pegando os dados do formulario
        Evento::create($dados);
        return redirect('evento')->withMessage('Evento Gravado com sucesso!');
    }

    public function index(){
        $endereco = $this->url;
        $eventos = [];

        if(Auth::user()->tipo == 'C')
            $eventos = Evento::where('user_id', Auth::user()->id)->get();
        else
            $eventos = Evento::all();

        return view('evento.list',compact('eventos','endereco'));
    }

    public function edit($id){
        $users = User::where('tipo', 'C')->get();
        $usuario = [];
        foreach ($users as $key => $value) {
            $usuario[$value->id] = $value->nome.' - '.$value->matricula;
        }

        $e = Evento::find($id);
        $status = ['A' => 'Aberto', 'F' => 'Fechado'];
        return view('evento.edit', compact('e', 'status', 'usuario'));
    }

    public function update(EventoRequest $request, $id){
        // salvar no banco
        $dados = $request->all();
        if(Auth::user()->tipo == 'C')
            $dados['user_id'] = Auth::user()->id;

        Evento::find($id)->update($dados);
        return redirect('evento')->withMessage('Evento Atualizado com sucesso!');
    }

    public function delete($id){
        Evento::find($id)->delete();
        return redirect('evento')->withMessage('Evento excluido com sucesso!');
    }
    public function deleteInscricao($id){
        $evento_id = Inscricao::find($id)->evento_id;
        Inscricao::find($id)->delete();

        return redirect('evento/participantes/'.$evento_id)->withMessage('Participante excluido com sucesso!');
    }

    public function ver($id){
        #if(Auth::user()->tipo != 'C')
        #    return redirect('dashboard');
        $ps = [];
        //Dados do Banco:
        if(Auth::user()->tipo != 'G')
            $ps = DB::select('SELECT DISTINCT p.* ,i.id as in_id FROM participantes AS p, inscricaos AS i, eventos AS e
              WHERE i.participante_id = p.id AND i.evento_id = e.id AND e.user_id = ? AND e.id = ?', [Auth::user()->id, $id]);
        else
            $ps = DB::select('SELECT DISTINCT p.* ,i.id as in_id FROM participantes AS p, inscricaos AS i, eventos AS e
              WHERE i.participante_id = p.id AND i.evento_id = e.id AND  e.id = ?', [$id]);
        if(!count($ps))
            return redirect('evento')->withErrors(array('Evento sem participantes'));            

        $e = Evento::find($id);
        #$c = Configuracao::find(1);
        #$c['data_hora'] = $this->getDataNow();
        #$c['codigo'] = $this->getCode($e->nome, '-');
        return view('evento.participantes', compact('e', 'ps', 'c'));
        #return $this->getPDF($ps, $e, $c, true)->show();
    }

    public function frequencia($id){
        #if(Auth::user()->tipo != 'C')
        #    return redirect('dashboard');
        $ps = [];
        //Dados do Banco:
        #Model::select(DB::raw('query'))->get();
        if(Auth::user()->tipo != 'G')
            $ps = DB::select('SELECT DISTINCT p.* FROM participantes AS p, inscricaos AS i, eventos AS e
            WHERE i.participante_id = p.id AND i.evento_id = e.id AND e.user_id = ? AND e.id = ?', [Auth::user()->id, $id]);
        else
            $ps = DB::select('SELECT DISTINCT p.* FROM participantes AS p, inscricaos AS i, eventos AS e
            WHERE i.participante_id = p.id AND i.evento_id = e.id AND e.id = ?', [$id]);
        #$vector = array();
        
        #foreach ($ps as $key => $value) {
        #    $vector[$key] = Participante::where('id', $value->id)->get();
        #}

        #return $vector;

        #$ps = 

        if(!count($ps))
            return redirect('evento')->withErrors(array('Evento sem participantes'));            

        $e = Evento::find($id);

        #$t = $e->inscricaos()->first();

        #return $t;

        $c = Configuracao::find(1);
        $c['data_hora'] = $this->getDataNow();
        $c['codigo'] = $this->getCode($e->nome, '-');

        return $this->getPDF($ps, $e, $c, 2)->show();
    }

    public function certificadoGeral($id){
        #if(Auth::user()->tipo != 'C')
        #    return redirect('dashboard');
        $ps = [];
        //Dados do Banco:
        #Model::select(DB::raw('query'))->get();
        if(Auth::user()->tipo != 'G')
            $ps = DB::select('SELECT DISTINCT p.* FROM participantes AS p, inscricaos AS i, eventos AS e
            WHERE i.participante_id = p.id AND i.evento_id = e.id AND e.user_id = ? AND e.id = ?', [Auth::user()->id, $id]);
        else
            $ps = DB::select('SELECT DISTINCT p.* FROM participantes AS p, inscricaos AS i, eventos AS e
            WHERE i.participante_id = p.id AND i.evento_id = e.id AND e.id = ?', [$id]);
        #$vector = array();

        #foreach ($ps as $key => $value) {
        #    $vector[$key] = Participante::where('id', $value->id)->get();
        #}

        #return $vector;

        #$ps =

        if(!count($ps))
            return redirect('evento')->withErrors(array('Evento sem participantes'));

        $e = Evento::find($id);

        #$t = $e->inscricaos()->first();

        #return $t;

        $c = Configuracao::find(1);
        $c['data_hora'] = $this->getDataNow();
        $c['codigo'] = $this->getCode($e->nome, '-');

        return $this->getPDF($ps, $e, $c, 1)->show();
    }

    public function eventosAbertos(){
        #if(Auth::user()->tipo != 'C')
        #    return redirect('dashboard');

        //Dados do Banco:
        #Model::select(DB::raw('query'))->get();

        if(Auth::user()->tipo != 'G'){

            $es = DB::select('SELECT DISTINCT e.* FROM eventos AS e
            WHERE e.user_id = ?', [Auth::user()->id]);

        }else{
            $es = DB::select('SELECT DISTINCT e.* FROM eventos AS e');

        }




        #$vector = array();
        
        #foreach ($ps as $key => $value) {
        #    $vector[$key] = Participante::where('id', $value->id)->get();
        #}

        #return $vector;

        #$ps = 

        if(!count($es))
            return redirect('evento')->withErrors(array('Sem eventos'));            

        //$e = Evento::find($id);

        #$t = $e->inscricaos()->first();

        #return $t;

        $e = null;

        $c = Configuracao::find(1);
        #$c['data_hora'] = $this->getDataNow();
        #$c['codigo'] = $this->getCode($e->nome, '-');

        return $this->getPDF($es, $e, $c, 3)->show();
    }

    public function participantesEvento(){
        #if(Auth::user()->tipo != 'C')
        #    return redirect('dashboard');

        //Dados do Banco:
        #Model::select(DB::raw('query'))->get();

        if(Auth::user()->tipo != 'G'){
            $es = DB::select('SELECT DISTINCT e.*, count(i.id) as qtd FROM eventos AS e,
            inscricaos as i WHERE e.user_id = ? AND i.evento_id = e.id GROUP BY (e.id)', [Auth::user()->id]);

        }else{
            $es = DB::select('SELECT DISTINCT e.*, count(i.id) as qtd FROM eventos AS e,
            inscricaos as i WHERE
             i.evento_id = e.id GROUP BY (e.id)');

        }


        #$vector = array();
        
        #foreach ($ps as $key => $value) {
        #    $vector[$key] = Participante::where('id', $value->id)->get();
        #}

        #return $vector;

        #$ps = 

        if(!count($es))
            return redirect('evento')->withErrors(array('Sem eventos'));            

        //$e = Evento::find($id);

        #$t = $e->inscricaos()->first();

        #return $t;

        $e = null;

        $c = Configuracao::find(1);
        #$c['data_hora'] = $this->getDataNow();
        #$c['codigo'] = $this->getCode($e->nome, '-');

        return $this->getPDF($es, $e, $c, 4)->show();

    }

    public function gerenteEvento(){
        $es = Evento::all();

        foreach ($es as $key => $value) {
            # code...

            $es[$key]['ps'] = DB::select('SELECT DISTINCT p.*, i.id as in_id FROM participantes as p, inscricaos as i, eventos as e
       		WHERE i.participante_id = p.id and i.evento_id = e.id and e.id = ?	',[$value->id]);
        }

        //return $es; //view('participante.list',compact('participantes', 'eventos'));
        return view('evento.evento_gerente',compact('es'));



    }

}