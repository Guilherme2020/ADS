<?php
/**
 * Created by PhpStorm.
 * User: grodrigues
 * Date: 19/04/16
 * Time: 01:21
 */

namespace App\Http\Controllers;

use App\Configuracao;
use App\Http\Requests\ConfiguracaoRequest;
use Illuminate\Support\Facades\DB;
use Auth;

class ConfiguracaoController extends BaseController{

    public function __construct(){
        parent::__construct();
        $this->middleware('auth');
    }

    public function add(){
        $c = Configuracao::find(1);
        return view('configuracao.add', compact('c'));
    }

    public function save(ConfiguracaoRequest $request){
        // Pegando os dados do formulario
        $dados = $request->all();
        $c = Configuracao::find(1);
        if($c->configurado == 'N')
            $dados['configurado'] = 'S';
        $c->update($dados);

        return redirect('dashboard')->withMessage('Configuracoes salvas com sucesso!');
    }
    
    public function view(){
        $c = Configuracao::find(1);
        return view('configuracao.view', compact('c'));
    }

}