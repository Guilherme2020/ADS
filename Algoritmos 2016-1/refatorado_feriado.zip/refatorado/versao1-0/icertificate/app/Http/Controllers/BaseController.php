<?php

namespace App\Http\Controllers;
use Auth;
use View;
use Carbon\Carbon;
use PDF;
use Mail;

class BaseController extends Controller{
    public $header;

    public function __construct(){
        $this->middleware('auth');
        //Opcoes:
        $options = array(
			'A' => 'admin',
			'G' => 'gerente',
			'C' => 'coordenador',
        );
        // Fetch the Site Settings object
        $this->header = $options[Auth::user()->tipo];
        
        View::share('header', $this->header);
    }

    //Get Data Now:
    public function getDataNow(){
        setlocale(LC_ALL, NULL);
        setlocale(LC_ALL, 'pt_BR');
        return ucwords(Carbon::now()->formatLocalized('%d de %B de %Y'));
    }
    //Generate PDF
    public function getPDF($ps, $e, $c, $multiple = 0){
        $html = null;
        
        if($multiple == 1 || $multiple === true){
            $html = view('certificados.main', compact('ps', 'e', 'c'))->render();
        }else if($multiple == 2){
            $html = view('certificados.frequencia', compact('ps', 'e', 'c'))->render();
        }else if($multiple == 3){
            $html = view('evento.eventos_abertos', compact('ps'))->render();
        }else if($multiple == 4){
            $html = view('evento.participantes_evento', compact('ps'))->render();
        }else{
            $p = $ps;
            $html = view('certificados.unique', compact('p', 'e', 'c'))->render();
        }
        
        return PDF::load($html, 'A4', 'landscape');
    }
    
    public function getCode($a, $b){
        return md5($a.$b);
    }

    //Send Email:
    public function sendMail($view, $data, $post_data){
        #\print_r(123);
        

        return Mail::send('emails.'.$view, $data, function($message) use($post_data){
            $message->from('info@icertificate.com', 'iCertificate');
            $message->to($post_data['email'])->subject($post_data['subject']);

            if(isset($post_data['pdf']))
                $message->attachData($post_data['pdf']->output(), 'certificado.pdf');
        });
    }

    public function validarCpf($cpf = null){
        // Verifica se um número foi informado
        if(empty($cpf)) {
            return false;
        }

        // Elimina possivel mascara
        $cpf = preg_replace('/[^0-11]/', '', $cpf);
        $cpf = str_pad($cpf, 11, '0', STR_PAD_LEFT);

        // Verifica se o numero de digitos informados é igual a 11
        if (strlen($cpf) != 11) {
            return false;
        }
        // Verifica se nenhuma das sequências invalidas abaixo
        // foi digitada. Caso afirmativo, retorna falso
        else if ($cpf == '00000000000' ||
            $cpf == '11111111111' ||
            $cpf == '22222222222' ||
            $cpf == '33333333333' ||
            $cpf == '44444444444' ||
            $cpf == '55555555555' ||
            $cpf == '66666666666' ||
            $cpf == '77777777777' ||
            $cpf == '88888888888' ||
            $cpf == '99999999999') {
            return false;
            // Calcula os digitos verificadores para verificar se o
            // CPF é válido
        } else {

            for ($t = 9; $t < 11; $t++) {

                for ($d = 0, $c = 0; $c < $t; $c++) {
                    $d += $cpf{$c} * (($t + 1) - $c);
                }
                $d = ((10 * $d) % 11) % 10;
                if ($cpf{$c} != $d) {
                    return false;
                }
            }

            return true;
        }
    }

}

