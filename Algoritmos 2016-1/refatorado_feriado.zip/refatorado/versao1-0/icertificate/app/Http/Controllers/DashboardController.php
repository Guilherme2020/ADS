<?php

namespace App\Http\Controllers;
use Auth;
use Session;

class DashBoardController extends BaseController{

    public function __construct(){
        parent::__construct();
    }

    public function dashboard(){
        Session::put('layout', $this->header);
        return view('welcome');
    }
}
?>