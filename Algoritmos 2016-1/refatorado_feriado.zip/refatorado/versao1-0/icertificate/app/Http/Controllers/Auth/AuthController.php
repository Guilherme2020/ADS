<?php

namespace App\Http\Controllers\Auth;

use App\Http\Requests\RegisterRequest;
use App\Http\Requests\LoginRequest;
use App\User;
use Session;
use Auth;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\Auth\Guard;

use App\Http\Requests\Request;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

class AuthController extends Controller{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = 'dashboard';

    protected $user;
    protected $auth;

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct(Guard $auth, User $user){
        $this->user = $user;
        $this->auth = $auth;

        $this->middleware($this->guestMiddleware(), ['except' => ['getLogout', 'logout']]);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    #protected function validator(array $data){
    #    return Validator::make($data, [
    #        'name' => 'required|max:255',
    #        'email' => 'required|email|max:255|unique:users',
    #        'password' => 'required|min:6|confirmed',
    #    ]);
    #}

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    #protected function create(array $data){
    #    return User::create([
    #        'name' => $data['name'],
    #        'email' => $data['email'],
    #        'password' => bcrypt($data['password']),
    #    ]);
    #}

    //Registro:
    public function getRegister(){
        return view('auth.register');
    }

    public function postRegister(RegisterRequest $request){
        $this->create($request->all());
        return redirect('login');
    }
    //Fim Registro;

    public function getLogout(){
        $this->auth->logout();
        Session::flush();
        #return redirect(property_exists($this, 'redirectAfterLogout') ? $this->redirectAfterLogout : '/');
        return redirect('login')->withMensagem('Logout Efetuado com sucesso!');
    }

    //Login:
    public function getLogin(){
        if(Auth::check())
            return redirect('dashboard');

        return view('auth.login');
    }

    public function postLogin(LoginRequest $request){
        $dados = $request->all();
        #$request->only('matricula', 'password'))
        if ($this->auth->attempt(array('matricula' => $dados['matricula'], 'password' => $dados['password']))){
            //Define Layout na Sessao:
            
            //
            return redirect('dashboard');
        }else{

            return redirect('login')->withErrors([
                'matricula' => 'Matricula ou senha errados tente novamente!',
            ]);
        }
    }
    //FIM Login;
}
