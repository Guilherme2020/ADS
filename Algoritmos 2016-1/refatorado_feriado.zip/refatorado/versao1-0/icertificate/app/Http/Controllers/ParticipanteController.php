<?php
/**
 * Created by PhpStorm.
 * User: grodrigues
 * Date: 30/09/16
 * Time: 17:01
 */

    namespace App\Http\Controllers;


    use App\Http\Requests\ParticipanteRequest;
    use Illuminate\Support\Facades\Auth;
    use App\Participante;
    use App\Configuracao;
    use App\User;
    use App\Evento;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Event;
    use Request;


    class ParticipanteController extends BaseController
    {

        public function __construct()
        {
            parent::__construct();
        }

        public function set()
        {
            $es = Evento::where('user_id',Auth::user()->id)->get();

            foreach ($es as $key => $value) {
                $es[$key]['ps'] = DB::select('SELECT DISTINCT p.*,i.id in_in from participantes as p, inscricaos as
              i, eventos

                as e  WHERE i.participantes_id = p.id and i.evento_id = e.id and e.id = ? ',[$value->id]);
            }
            //return $es; //view('participante.list',compact('participantes', 'eventos'));

            return view('participante.list',compact('es'));

        }

        public function edit($id){

            $p =  Participante::find($id);
            return view("participante.edit")->with('p',$p);
        }

        public function  update(ParticipanteRequest $request, $id){
            Participante::find($id)->updat($request->all());

            return redirect('dashboard')->withMessage("Participante Atualizado com sucesso! ");
        }

        public function delete($id){

            Participante::find($id)->delete();
            return redirect("")->withMessage('Participante excluido com sucesso');
        }

        public function certificado($id){
            //    return redirect('dashboard');
            if(Auth::user()->tipo != 'G')
                //Dados do Banco:
                $p = DB::select('SELECT DISTINCT p.* FROM participantes AS p, inscricaos AS i, eventos AS e
            WHERE i.participante_id = p.id AND i.evento_id = e.id AND e.user_id = ? AND i.id = ?', [Auth::user()->id, $id])[0];
            else
                $p = DB::select('SELECT DISTINCT p.* FROM participantes AS p, inscricaos AS i, eventos AS e
            WHERE i.participante_id = p.id AND i.evento_id = e.id AND i.id = ?', [$id])[0];
            $e = DB::select('SELECT e.* FROM eventos as e, inscricaos as i
        	WHERE e.id = i.evento_id AND i.id = ?', [$id])[0];

            //Mudando configuracao:
            $c = Configuracao::find(1);
            $c['data_hora'] = $this->getDataNow();
            $c['codigo'] = $this->getCode($e->nome, $p->nome);

            return $this->getPDF($p, $e, $c)->show();
        }

        public function enviaCertificado($id){
            if(Auth::user()->tipo != 'C')
                return redirect('dashboard');

            //Dados do Banco:
            $p = DB::select('SELECT DISTINCT p.* FROM participantes AS p, inscricaos AS i, eventos AS e
            WHERE i.participante_id = p.id AND i.evento_id = e.id AND e.user_id = ? AND i.id = ?', [Auth::user()->id, $id])[0];

            $e = DB::select('SELECT e.* FROM eventos as e, inscricaos as i
        	WHERE e.id = i.evento_id AND i.id = ?', [$id])[0];

            //Mudando configuracao:
            $c = Configuracao::find(1);
            $c['data_hora'] = $this->getDataNow();
            $c['codigo'] = $this->getCode($e->nome, $p->nome);

            $data = array(
                'username' => $p->nome,
                'nome_evento' => $e->nome,
            );

            $post_data = array(
                'pdf' => $this->getPDF($p, $e, $c),
                'email' => $p->email,
                'subject' => 'Envio de E-mail',
            );

            return $this->sendMail('get_certificado', $data, $post_data);
            #try {

            return redirect('dashboard')->withMessage('E-mail em processo de envio');
            #} catch (Exception $e) {
            #  return redirect('dashboard')->withErrors(array('Erro no envio de e-mail'));
            #}
        }
        //

    }