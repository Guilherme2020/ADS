<?php
namespace App\Http\Controllers;
#namespace App\Http\Controllers\Redirect;
use App\User;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\UserRequest;

class UserController extends BaseController{

    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $users = User::all();
        return view('user.list', compact('users'));
    }



    public function getAdd(){
        //Simple ACL:
        if(Auth::user()->tipo == 'C')
            return redirect('dashboard')->withError('Voce nao tem autorizacao para isso!');

        return view('user.add', compact(''));
    }

    public function postAdd(UserRequest $request){
        //Gravando:
        $vetor = $request->all();
        $vetor['password'] = bcrypt($vetor['password']);
        User::create($vetor);
        return redirect('user')->withMessage('Usuario cadastrado com sucesso!');
    }

    public function delete($id){
        User::find($id)->delete();
        return redirect('user')->withMessage('Usuario Excluido com sucesso!');
        #withMessage('Usuario Excluido com sucesso!');
    }

    public function view($id){
        $user = User::find($id);
        return view('user.view', compact('user'));
    }

    public function edit($id){
        $u = User::find($id);
        return view('user.edit',compact('u'));
    }

    public function update(UserRequest $request, $id){
         //Gravando:
        $vetor = $request->all();
        if(!isset($vetor['mesma_senha'])){

            $vetor['password'] = bcrypt($vetor['password']);
        }else{
            unset($vetor['password']);
        }

        User::find($id)->update($vetor);
        //User::find($id)->update()
        return redirect('user')->withMessage('Usuario editado com sucesso!');
    }
}
?>
