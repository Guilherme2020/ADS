<?php
/**
 * Created by PhpStorm.
 * User: grodrigues
 * Date: 19/04/16
 * Time: 01:56
 */
    namespace App\Http;
    use DateTime;

class Helpers{

    public static function getList($list,$campo = 'nome'){
        $listas = ['' => 'Selecione uma opcao'];

        foreach ($list as $value){
            $listas[$value->id] = $value->$campo;
        }

        return $listas;
    }
}
?>