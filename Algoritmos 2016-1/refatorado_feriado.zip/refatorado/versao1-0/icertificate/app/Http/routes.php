<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::group(['middleware' => ['web']], function(){
	Route::get('/', 'Auth\AuthController@getLogin');
	Route::get('login', 'Auth\AuthController@getLogin');
	Route::post('login', 'Auth\AuthController@postLogin');

	#Route::get('/', 'HomeController@index');
	// Rotas de Autenticacao:
	// FIM Rotas de Autenticacao;

	Route::get('evento/cadastro/{slug}','HomeController@cadastro');
	Route::post('evento/cadastro/{slug}','HomeController@saveCadastro');
	
	Route::get('login', 'Auth\AuthController@getLogin');
	Route::post('login', 'Auth\AuthController@postLogin');
});

Route::group(['middleware' => ['guest']], function(){
	
});

Route::group(['middleware' => ['auth']], function(){



	Route::get('logout', 'Auth\AuthController@getLogout');
	Route::get('dashboard', 'DashboardController@dashboard');
	
	//Evento:
	Route::get('evento/add','EventoController@add');
	Route::post('evento/add','EventoController@save');
	Route::get('evento','EventoController@index');
	Route::get('evento/edit/{id}','EventoController@edit');
	Route::put('evento/edit/{id}','EventoController@update');
	Route::get('evento/participantes/{id}','EventoController@ver');
	Route::get('evento/frequencia/{id}','EventoController@frequencia');
	Route::get('evento/delete/{id}','EventoController@delete');
	Route::get('evento/deleteInscricao/{id}','EventoController@deleteInscricao');
	Route::get('evento/eventos_abertos','EventoController@eventosAbertos');
	Route::get('evento/participantes_evento','EventoController@participantesEvento');
    Route::get('evento/participantes','EventoController@gerenteEvento');
    Route::get('evento/certificados/{id}','EventoController@certificadoGeral');


    //Frequencia:
    Route::get('frequencia/add/{id}','FrequenciaController@add');
    Route::post('frequencia/add/{id}','FrequenciaController@save');
    Route::get('frequencia','FrequenciaController@index');
    Route::get('frequencia/edit/{id}','FrequenciaController@edit');
    Route::put('frequencia/edit/{id}','FrequenciaController@update');
    Route::get('frequencia/delete/{id}','FrequenciaController@delete');
    Route::get('frequencia/view/{id}','FrequenciaController@view');

    Route::get('frequencia/printer/{id}','FrequenciaController@printer');

    //Configuracao:
    Route::get('configuracao/add','ConfiguracaoController@add');
    Route::post('configuracao/add','ConfiguracaoController@save');
    Route::get('configuracao','ConfiguracaoController@view');

    //Participante:
    Route::get('participante','ParticipanteController@set');
    Route::get('participante/edit/{id}','ParticipanteController@edit');
    Route::put('participante/edit/{id}','ParticipanteController@update');
    Route::get('participante/delete/{id}','ParticipanteController@delete');
    Route::get('participante/certificado/{id}','ParticipanteController@certificado');
	Route::get('participante/enviar/{id}','ParticipanteController@enviaCertificado');

	//ADMIN ROUTE:
	Route::get('user/add', 'UserController@getAdd');
	Route::post('user/add', 'UserController@postAdd');
	Route::get('user', 'UserController@index');
	Route::get('user/view/{id}', 'UserController@view');
	Route::get('user/edit/{id}', 'UserController@edit');
	Route::put('user/edit/{id}', 'UserController@update');
	Route::get('user/delete/{id}', 'UserController@delete');
	//
});