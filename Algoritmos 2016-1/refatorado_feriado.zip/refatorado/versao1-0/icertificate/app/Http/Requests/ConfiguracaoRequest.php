<?php namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ConfiguracaoRequest extends FormRequest {

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(){
        return [
            'instituicao' => 'required',
            'cidade' => 'required',
            'estado' => 'required',
            'nome_superior'=> 'required',
            'cargo_superior'=> 'required',
            'nome_responsavel'=> 'required',
            'cargo_responsavel'=> 'required',
            'setor' => 'required',
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(){
        return true;
    }
}