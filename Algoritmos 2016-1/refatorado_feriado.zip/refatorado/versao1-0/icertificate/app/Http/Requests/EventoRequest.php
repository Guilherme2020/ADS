<?php namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EventoRequest extends FormRequest {

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(){
        /*switch($this->method()){
            case 'GET':
            case 'DELETE':{
                return [];
            }
            case 'POST':{*/
                return [
                    //'user_id' => 'required',
                    //'data_fim' => 'required',
                    'nome'=>'required|unique:eventos,nome,'.$this->id,
                    'data_inicio' => 'required',
                    'status'=> 'required|in:A,F',
                    'carga_horaria' => 'required',
                ];
            /*}
            case 'PUT':
            case 'PATCH':{
                return [
                    //'user_id' => 'required',
                    //'data_fim' => 'required',
                    'nome'=>'required|unique:eventos,nome'.$this->get('id'),
                    'data_inicio' => 'required',
                    'status'=> 'required|in:A,F',
                    'carga_horaria' => 'required',
                ];
            }
            default:break;
        }*/  
        //  
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(){
        return true;
    }
}