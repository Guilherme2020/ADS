<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Configuracao extends Model{
	public $timestamps = false;
	
    protected $fillable = ['instituicao','cidade', 'estado', 'configurado'
    ,'nome_superior', 'cargo_superior', 'nome_responsavel', 'cargo_responsavel', 'setor'];

}
?>

