<?php
/**
 * Created by PhpStorm.
 * User: grodrigues
 * Date: 26/04/16
 * Time: 09:52
 */

namespace App;
    use Illuminate\Database\Eloquent\Model;



class Inscricao extends Model {

    protected $fillable = ['status', 'evento_id', 'participante_id'];
	

     public function participante(){
        return $this->hasOne('App\Participante');
    }
}