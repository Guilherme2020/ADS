-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           5.6.24 - MySQL Community Server (GPL)
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura para tabela icertificate.certificados
DROP TABLE IF EXISTS `certificados`;
CREATE TABLE IF NOT EXISTS `certificados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `livro_id` int(10) unsigned NOT NULL,
  `inscricao_id` int(10) unsigned NOT NULL,
  `codigo` varchar(255) NOT NULL,
  `carga_horaria` int(10) unsigned NOT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela icertificate.certificados: ~0 rows (aproximadamente)
DELETE FROM `certificados`;
/*!40000 ALTER TABLE `certificados` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificados` ENABLE KEYS */;


-- Copiando estrutura para tabela icertificate.configuracaos
DROP TABLE IF EXISTS `configuracaos`;
CREATE TABLE IF NOT EXISTS `configuracaos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `instituicao` varchar(255) DEFAULT NULL,
  `cidade` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `configurado` varchar(1) DEFAULT 'N',
  `nome_superior` varchar(255) DEFAULT NULL,
  `cargo_superior` varchar(255) DEFAULT NULL,
  `nome_responsavel` varchar(255) DEFAULT NULL,
  `cargo_responsavel` varchar(255) DEFAULT NULL,
  `setor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela icertificate.configuracaos: ~3 rows (aproximadamente)
DELETE FROM `configuracaos`;
/*!40000 ALTER TABLE `configuracaos` DISABLE KEYS */;
INSERT INTO `configuracaos` (`id`, `instituicao`, `cidade`, `estado`, `configurado`, `nome_superior`, `cargo_superior`, `nome_responsavel`, `cargo_responsavel`, `setor`) VALUES
	(1, 'Instituto Federal do Piauí', 'Teresina', 'Piauí', 'S', 'Paulo Henrique Gomes', 'Reitor', 'Ana Claudia Galvao Xavier', 'Diretora de Extensão', 'Diretoria de Extensão'),
	(2, NULL, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL),
	(3, NULL, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL),
	(4, NULL, NULL, NULL, 'N', NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `configuracaos` ENABLE KEYS */;


-- Copiando estrutura para tabela icertificate.eventos
DROP TABLE IF EXISTS `eventos`;
CREATE TABLE IF NOT EXISTS `eventos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `nome` varchar(255) NOT NULL,
  `status` varchar(1) NOT NULL DEFAULT 'A',
  `data_inicio` date NOT NULL,
  `data_fim` date DEFAULT NULL,
  `numero_frequencias` int(11) DEFAULT '0',
  `slug` varchar(255) NOT NULL,
  `carga_horaria` int(10) unsigned DEFAULT '0',
  `nome_superior` varchar(255) DEFAULT NULL,
  `cargo_superior` varchar(255) DEFAULT NULL,
  `modalidade` varchar(1) DEFAULT NULL,
  `nome_responsavel` varchar(255) DEFAULT NULL,
  `cargo_responsavel` varchar(255) DEFAULT NULL,
  `qtd_vagas` int(11) DEFAULT NULL,
  `qtd_vagas_atual` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela icertificate.eventos: ~4 rows (aproximadamente)
DELETE FROM `eventos`;
/*!40000 ALTER TABLE `eventos` DISABLE KEYS */;
INSERT INTO `eventos` (`id`, `user_id`, `nome`, `status`, `data_inicio`, `data_fim`, `numero_frequencias`, `slug`, `carga_horaria`, `nome_superior`, `cargo_superior`, `modalidade`, `nome_responsavel`, `cargo_responsavel`, `qtd_vagas`, `qtd_vagas_atual`) VALUES
	(1, 7, 'Teste de Novo Evento', 'A', '1995-12-11', '1995-12-11', 0, 'teste-de-novo-evento', 0, NULL, NULL, '', NULL, NULL, 0, NULL),
	(2, 7, 'Novo Teste de Evento', 'A', '1995-12-11', '1995-12-11', 0, 'novo-teste-de-evento', 0, NULL, NULL, '', NULL, NULL, 0, NULL),
	(4, 9, 'Matlab para iniciantes', 'A', '2016-06-07', '2016-06-02', 0, 'matlab-para-iniciantes', 50, NULL, NULL, '', NULL, NULL, NULL, NULL),
	(5, 9, 'Matematica Computacional Para Adolescentes', 'A', '2016-09-06', '2016-11-06', 0, 'matematica-computacional-para-adolescentes', 40, NULL, NULL, '', NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `eventos` ENABLE KEYS */;


-- Copiando estrutura para tabela icertificate.frequencias
DROP TABLE IF EXISTS `frequencias`;
CREATE TABLE IF NOT EXISTS `frequencias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `evento_id` int(10) unsigned NOT NULL,
  `descricao` text,
  `data` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela icertificate.frequencias: ~0 rows (aproximadamente)
DELETE FROM `frequencias`;
/*!40000 ALTER TABLE `frequencias` DISABLE KEYS */;
/*!40000 ALTER TABLE `frequencias` ENABLE KEYS */;


-- Copiando estrutura para tabela icertificate.inscricaos
DROP TABLE IF EXISTS `inscricaos`;
CREATE TABLE IF NOT EXISTS `inscricaos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `participante_id` int(10) unsigned NOT NULL,
  `evento_id` int(10) unsigned NOT NULL,
  `status` varchar(2) DEFAULT 'NC',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela icertificate.inscricaos: ~4 rows (aproximadamente)
DELETE FROM `inscricaos`;
/*!40000 ALTER TABLE `inscricaos` DISABLE KEYS */;
INSERT INTO `inscricaos` (`id`, `participante_id`, `evento_id`, `status`, `created_at`, `updated_at`) VALUES
	(1, 3, 1, 'P', '2016-06-06 08:15:02', '2016-06-06 08:15:02'),
	(2, 4, 1, 'P', '2016-06-06 05:18:41', '2016-06-06 05:18:41'),
	(3, 5, 3, 'P', '2016-06-06 07:14:21', '2016-06-06 07:14:21'),
	(4, 6, 3, 'P', '2016-06-06 21:36:58', '2016-06-06 21:36:58'),
	(5, 7, 4, 'P', '2016-06-12 13:48:25', '2016-06-12 13:48:25');
/*!40000 ALTER TABLE `inscricaos` ENABLE KEYS */;


-- Copiando estrutura para tabela icertificate.livros
DROP TABLE IF EXISTS `livros`;
CREATE TABLE IF NOT EXISTS `livros` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero` int(10) unsigned NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `modified_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela icertificate.livros: ~0 rows (aproximadamente)
DELETE FROM `livros`;
/*!40000 ALTER TABLE `livros` DISABLE KEYS */;
/*!40000 ALTER TABLE `livros` ENABLE KEYS */;


-- Copiando estrutura para tabela icertificate.participantes
DROP TABLE IF EXISTS `participantes`;
CREATE TABLE IF NOT EXISTS `participantes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `matricula` varchar(20) DEFAULT NULL,
  `nome` varchar(255) NOT NULL,
  `cpf` varchar(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela icertificate.participantes: ~2 rows (aproximadamente)
DELETE FROM `participantes`;
/*!40000 ALTER TABLE `participantes` DISABLE KEYS */;
INSERT INTO `participantes` (`id`, `matricula`, `nome`, `cpf`, `email`) VALUES
	(3, '20151ADS0129', 'DANIEL DA SILVA FARIAS', '05839288381', 'ddanielsilva661@gmail.com'),
	(4, '20151ADS0128', 'JUNIOR CARAPEBA', '05839288382', 'ddanielsilva662@gmail.com'),
	(5, '20151ADS0127', 'DANIEL DA SILVA FARIAS', '05839288380', 'ddanielsilva663@gmail.com'),
	(6, '', 'DANIEL DA SILVA FARIAS', '05839288383', 'ddanielsilva664@gmail.com'),
	(7, '20151ADS0130', 'DANIEL DA SILVA FARIAS', '05839288388', 'ddanielsilva668@gmail.com');
/*!40000 ALTER TABLE `participantes` ENABLE KEYS */;


-- Copiando estrutura para tabela icertificate.presencas
DROP TABLE IF EXISTS `presencas`;
CREATE TABLE IF NOT EXISTS `presencas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `inscricao_id` int(10) unsigned NOT NULL DEFAULT '0',
  `frequencia_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` varchar(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela icertificate.presencas: ~0 rows (aproximadamente)
DELETE FROM `presencas`;
/*!40000 ALTER TABLE `presencas` DISABLE KEYS */;
/*!40000 ALTER TABLE `presencas` ENABLE KEYS */;


-- Copiando estrutura para tabela icertificate.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `matricula` varchar(20) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `cpf` varchar(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `rg` varchar(100) NOT NULL,
  `tipo` varchar(1) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela icertificate.users: ~2 rows (aproximadamente)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `matricula`, `nome`, `cpf`, `email`, `rg`, `tipo`, `password`, `remember_token`) VALUES
	(6, '11111111', 'admin', '', '', '', 'A', '$2y$10$KB7orOqWU2vDaJQJepcsTOY0Up.1I0vqTWXWOQR0WZRHSMwTLdMiu', 'SL3cypSo4yuwKTBKk9uw4B36v3uM2HJVygCf2ZCVUxQiFV6ZJXGKiGuBky19'),
	(9, '20151ADS0129', 'DANIEL DA SILVA FARIAS', '05839288381', 'ddanielsilva661@gmail.com', '3544201', 'C', '$2y$10$uT.w2sebQ84GpjeW5HC4BOWi8f43HUNcjl3HMyeChT5U4XyqCfGQO', 'SnIAiMEUKzW1AH32sJD7y1HzWJBpGOrJhhU23olWMUCm5SX7kfPgq0e8JuRg'),
	(10, '11111111', 'ADMIN', '', '', '', 'A', 'admin', NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
