<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-15">
<style>
body { 
	font-family: verdana, sans-serif;
} 
table {
  margin-bottom: 2em;
  width: 100%;
  
}

thead {
  
}

tbody {
  
}

th,td {
  text-align: center;
  padding: 1pt;
}

table {
  
}

table td.assin {
  border-bottom: 1pt solid black;
  width: 35%;
}

.head{
	text-align: center;
}
</style>
</head>
<body>
<!---->
	<div class="head">
		<h2>Lista de Frequencia</h2>
		<h3>Evento: <?php echo e($e->nome); ?></h3>
	</div>
<!---->
<table> 
<thead>
  <tr>
    <th>Nome</th>
    <th>CPF</th>
    <th>Matricula</th>
    <th colspan="3">Assinatura</th>
  </tr>
</thead>
  <tbody>
<?php foreach($ps as $p): ?>
  <tr>
    <td><?php echo e(strtoupper($p->nome)); ?></td>
    <td><?php echo e(strtoupper($p->cpf)); ?></td>
    <td><?php echo e(strtoupper($p->matricula)); ?></td>
    <td colspan="3" class="assin"></td>
  </tr>
<?php endforeach; ?>
  </tbody>
</table>
</body>
</html>