

<?php $__env->startSection('context'); ?>
<div class="col-md-9">
    <h2>Lista de Eventos</h2>

    <table class="table table-bordered">
        <thead>
            <tr>
                <td>Nome</td>
                <td>Status</td>
                <td>Data</td>
                <td>Endereço</td>
                <td colspan="4">Ações</td>
            </tr>

        </thead>

        <?php foreach($eventos as $evento): ?>
            <tr>
                <td>
                    <?php echo e($evento->nome); ?>


                </td>
                <td>
                    <?php echo e($evento->status == 'A' ? 'Aberto' : 'Fechado'); ?>

                </td>
                <td>
                    <?php echo e($evento->data_inicio); ?> a <?php echo e($evento->data_fim); ?>

                </td>
                <td>
                    <a href="<?php echo e(url($endereco.$evento->slug)); ?>" target="_blank" class="btn btn-primary"><span class="glyphicon glyphicon-arrow-up"></span> Link</a>
                </td>

                <td>
                    <a class="btn btn-warning" href="<?php echo e(url('evento/edit/'.$evento->id)); ?>"><span class="glyphicon glyphicon-pencil"></span> Editar</a>
                </td>

                <td>
                    <a class="btn btn-warning" href="<?php echo e(url('frequencia/add/'.$evento->id)); ?>"><span class="glyphicon glyphicon-pencil"></span> Adicionar Frequencia</a>
                </td>

                <td>
                    <a class="btn btn-primary" href="<?php echo e(url('evento/participantes/'.$evento->id)); ?>"> Ver Participantes </a>
                </td>
                <td>
                    <a class="btn btn-danger" id="btn-apagar" href="<?php echo e(url('evento/delete/'.$evento->id)); ?>"><span class="glyphicon glyphicon-trash"></span>  Excluir</a>
                </td>
            </tr>


        <?php endforeach; ?>
    </table>

    <script type="text/javascript">
        $(document).ready(function(){
            $("#btn-apagar").click( function(event) {
                var apagar = confirm('Deseja realmente excluir este participante?');
                if (apagar){
                    // aqui vai a instrução para apagar registro
                }else{
                    event.preventDefault();
                }
            });
        });
    </script>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>