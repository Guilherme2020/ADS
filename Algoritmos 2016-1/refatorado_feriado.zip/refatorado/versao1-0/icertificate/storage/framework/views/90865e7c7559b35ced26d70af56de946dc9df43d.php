<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>iCertificate</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="<?php echo e(asset('assets/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/bootstrap/dist/css/bootstrap.css')); ?>" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <link href="<?php echo e(asset('assets/bootply_custom/styles.css')); ?>" rel="stylesheet">
    <!-- script references -->
    <script src="<?php echo e(asset('assets/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bootply_custom/scripts.js')); ?>"></script>
</head>
<body>
<!-- header -->
<div id="top-nav" class="navbar navbar-inverse navbar-static-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(Auth::user() ? url('/dashboard') : '#'); ?>">iCertificate</a>
            <ul class="nav navbar-nav">
                <li class="nav-header"><a href="<?php echo e(Auth::user() ? url('/dashboard') : '#'); ?>">Home</li></a>				 <!--<li class="dropdown">
					 <a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1
					 <span class="caret"></span></a>
					 <ul class="dropdown-menu">
						 <li><a href="#">Page 1-1</a></li>
						 <li><a href="#">Page 1-2</a></li>
						 <li><a href="#">Page 1-3</a></li>
					 </ul>
				 </li>-->
                <li class="nav-header"><a href="<?php echo e(url('evento/add')); ?>">Cadastrar Evento</li></a>

                <li><a href="<?php echo e(url('evento')); ?>">Lista de Eventos</a></li>
                <li><a href="<?php echo e(url('#')); ?>">Atividades</a></li>
                <li><a href="<?php echo e(url('user')); ?>">Usuarios</a></li>
                <li><a href="<?php echo e(url('#')); ?>">Frequencias</a></li>
                <?php /*<li><a href="<?php echo e(url('participante')); ?>">PARTICIPANTE></a></li>*/ ?>

            </ul>

        </div>

        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
                <?php echo $__env->yieldContent('menu_options'); ?>
            </ul>
        </div>

    </div>



    <!-- /container -->
</div>


<!-- /Header -->

<!--END HEAD-->
<div class="container-fluid">
    <div class="col-md-12">
        <!--ERRORS-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Opa!</strong> Algum(ns) problema(s) nos dados:<br><br>
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
                    <!--FIM ERRORS-->

            <!--MENSAGENS-->
            <?php if(isset($message)): ?>
                <div class="alert alert-success">
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                        <!--FIM MENSAGENS-->
                <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
<!--<footer class="text-center">iCertificate IFPI</footer>-->
<div class="modal" id="addWidgetModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title">Add Widget</h4>
            </div>
            <div class="modal-body">
                <p>Add a widget stuff here..</p>
            </div>
            <div class="modal-footer">
                <a href="#" data-dismiss="modal" class="btn">Close</a>
                <a href="#" class="btn btn-primary">Save changes</a>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<footer class="footer">
    <div class="container">
        <p>© Sistema Icertificate todos direitos Reservados ao IFPI.</p>
    </div>
</footer>
</body>
</html>
