<?php $__env->startSection('menu_options'); ?>
<?php $__env->stopSection(); ?>
<style>
    .red{
        color:red;
    }
</style>
<?php $__env->startSection('content'); ?>

    <?php echo Form::open(array('url' => 'participante/edit/'.$p->id, 'method' => 'put')); ?>

       <p>Campos com <span class="red"> * </span>são obrigatorios</p>

       <div class="form-group">
        	<?php echo Form::label('matricula', 'Matricula');; ?>


			<?php echo Form::text('matricula', $p->matricula, array('class' => 'form-control'));; ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('nome', 'Nome');; ?>


			<?php echo Form::text('nome', $p->nome, array('class' => 'form-control', 'required' => true));; ?>

        </div>

        <div class="form-group">
        	<?php echo Form::label('cpf', 'Cpf');; ?>


			<?php echo Form::text('cpf', $p->cpf, array('class' => 'form-control'));; ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('email', 'Email');; ?>


			<?php echo Form::text('email', $p->email, array('class' => 'form-control', 'required' => true));; ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Salvar', array('class' => 'btn btn-primary'));; ?>


			<?php echo Form::reset('Limpar', array('class' => 'btn btn-warning'));; ?>

        </div>
    <?php echo Form::close(); ?>

    <script type="text/javascript">
        $(document).ready(function(){
           //
            $("#cpf").inputmask("999.999.999-99");
           //
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>