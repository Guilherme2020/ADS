

<?php $__env->startSection('menu_options'); ?>
<li class="dropdown">
    <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#"><i class="glyphicon glyphicon-user"></i> <?php echo e(explode(" ", Auth::user()->nome)[0]); ?> <span class="caret"></span></a>
    <ul id="g-account-menu" class="dropdown-menu" role="menu">
        <li><a href="<?php echo e(url('user/edit')); ?>">Perfil</a></li>
        <li><a href="<?php echo e(url('logout')); ?>"><i class="glyphicon glyphicon-log-out"></i> Logout</a></li>
    </ul>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main -->
<div class="container-fluid">
    <div class="row-fluid">
        <div class="col-sm-3">
            <!-- Left column -->
            <a href="#"><strong><i class="glyphicon glyphicon-wrench"></i> Atividades</strong></a>
            <hr>

            <ul class="nav nav-stacked">
                <li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#userMenu">Cadastros <i class="glyphicon glyphicon-chevron-down"></i></a>
                    <ul class="nav nav-stacked collapse in" id="userMenu">
                        <li class="active"> <a href="<?php echo e(url('user/add')); ?>"><i class="glyphicon glyphicon-home"></i>Cadastrar Usuario</a></li>
                        <li><a href="<?php echo e(url('evento/add')); ?>"><i class="glyphicon glyphicon-envelope"></i> Cadastrar Evento <span class="badge badge-info">4</span></a></li>
                    </ul>
                </li>
                <li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#menu2"> Consultas <i class="glyphicon glyphicon-chevron-right"></i></a>

                    <ul class="nav nav-stacked collapse" id="menu2">
                        <li><a href="<?php echo e(url('evento')); ?>"> Eventos</a>
                        </li>
                        <li><a href="<?php echo e(url('user')); ?>"> Usuarios</a>
                        </li>
                        <li><a href="<?php echo e(url('evento/participantes')); ?>">Participantes</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-header">
                    <a href="#" data-toggle="collapse" data-target="#menu3"> Relatorios <i class="glyphicon glyphicon-chevron-right"></i></a>
                    <ul class="nav nav-stacked collapse" id="menu3">
                        <li><a target="_blank" href="<?php echo e(url('evento/eventos_abertos')); ?>"><i class="glyphicon glyphicon-circle"></i> Eventos Abertos</a></li>
                        <li><a target="_blank" href="<?php echo e(url('evento/participantes_evento')); ?>"><i class="glyphicon glyphicon-circle"></i> Participantes por evento</a></li>
                    </ul>
                </li>
            </ul>
            <hr>
            <!-- End Left column -->
        </div>
        <?php echo $__env->yieldContent('context'); ?>
        <!-- /col-3 -->
    </div>
</div>
<!-- /Main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>