

<?php $__env->startSection('context'); ?>
<div class="col-md-9">
    <h2>Lista de Usuarios</h2>

    <table class="table table-bordered">
        <thead>
            <tr>

                <td>Nome</td>
                <td>Matricula</td>
                <td>Email</td>
                <td>Tipo de Usuario</td>
                <td colspan="3">Ações</td>
            </tr>

        </thead>

        <?php foreach($users as $user): ?>
            <tr>
                <td>
                    <?php echo e($user->nome); ?>


                </td>
                <td>
                    <?php echo e($user->matricula); ?>

                </td>

                <td>
                    <?php echo e($user->email); ?>

                </td>
                <td>
                    <?php echo e($user->tipo); ?>

                </td>
                <td>
                    <a class="btn btn-warning" href="<?php echo e(url('user/edit/'.$user->id)); ?>"><span class="glyphicon glyphicon-pencil"></span> Editar</a>
                </td>
                <td>
                    <a class="btn btn-primary" href="<?php echo e(url('user/view/'.$user->id)); ?>"> Ver </a>
                </td>
                <td>
                    <a class="btn btn-danger delete" href="<?php echo e(url('user/delete/'.$user->id)); ?>"><span class="glyphicon glyphicon-trash"></span>  Excluir</a>
                </td>
            </tr>


        <?php endforeach; ?>
    </table>
</div>




  <script type="text/javascript">
  $(document).ready(function(){
     $(".delete").on("click", function(event) {
        var apagar = confirm('Deseja realmente excluir este registro de Usuario?');
        if (!apagar){
  	// aqui vai a instrução para apagar registro
          event.preventDefault();
        }
     });
  });

  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>