<p>Olá <strong><?php echo e($username); ?></strong>, tudo bem?</p>

<p>Obrigado pela participação no evento: <strong><?php echo e($nome_evento); ?></strong>!</p>

<p>Segue em anexo o seu certificado!</p>

<p>Abraços!</p>