
<style>
    .red{
        color:red;
    }
</style>
<?php $__env->startSection('context'); ?>
        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">Cadastrar Novo Usuario</div>
                <div class="panel-body">
                	<?php echo Form::open(array('url' => 'user/add', 'method' => 'post')); ?>


                        <p>Campos com <span class="red"> * </span>são obrigatorios</p>
                        <div class="form-group">
                            <?php echo Form::label('nome', 'Nome *');; ?>


							<?php echo Form::text('nome', null, array('class' => 'form-control'));; ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('cpf', 'Cpf *');; ?>


							<?php echo Form::text('cpf', null, array('class' => 'form-control'));; ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('rg', 'RG *');; ?>


							<?php echo Form::text('rg', null, array('class' => 'form-control'));; ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('matricula', 'Matricula *');; ?>


							<?php echo Form::text('matricula', null, array('class' => 'form-control'));; ?>

                        </div>

                        <div class ="form-group">
                        	<?php echo Form::label('tipo', 'Tipo de Usuario *');; ?>


							<?php echo Form::select('tipo', array('C' => 'Coordenador', 'G' => 'Gerente'), null, array('class' => 'form-control'));; ?>

                            
                        </div>

                        <div class="form-group">
                            <?php echo Form::label('email', 'Email *');; ?>


							<?php echo Form::text('email', null, array('class' => 'form-control', 'required' => true));; ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('password', 'Senha *');; ?>


							<?php echo Form::password('password', array('class' => 'form-control'));; ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('password_confirmation', 'Confirme a senha *');; ?>


							<?php echo Form::password('password_confirmation', array('class' => 'form-control'));; ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::submit('Salvar', array('class' => 'btn btn-primary'));; ?>


							<?php echo Form::reset('Limpar', array('class' => 'btn btn-warning'));; ?>

                        </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
    </div>



        <script type="text/javascript" src="<?php echo e(asset('assets/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js')); ?>"></script>


        <script type="text/javascript">
            $(document).ready(function(){
               //
                $("#cpf").inputmask("999.999.999-99");
               //
            });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>