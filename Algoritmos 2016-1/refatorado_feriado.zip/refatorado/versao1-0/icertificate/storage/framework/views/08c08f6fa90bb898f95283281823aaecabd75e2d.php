<style type="text/css">
	body{
		/**background-image: url(<?php echo e(asset('img/modelo_certificado.fw.png')); ?>);
		background-position: top left;
	    background-repeat: no-repeat;
	    background-size: 100%;*/

	    padding: 0px 0px 0px 0px;
	}

	.page { 
		border: 5px solid green;
		/*border: 1px solid black;*/
	}

	.title{
		text-align: center;
		font-family: Times;
		font-size: 60pt;
		text-transform: bold;
		margin-top: 80px; 
	}

	.main{
		text-align: justify;
		font-family: Verdana;
		margin-left: 50px;
		margin-right: 50px;
		font-size: 14pt;
		margin-top: 140px;
	}

	.footer{
		text-align: center;
		font-family: Verdana;
		font-size: 12pt;	
		margin-top: 80px;
	}
</style>

<div class="page">
	<p class="title">
		Certificado
	</p>

	<p class="main">
		A <?php echo e($c->setor); ?> do <?php echo e($c->instituicao); ?> certifica que <?php echo e(strtoupper($p->nome)); ?>, CPF
		<?php echo e($p->cpf); ?>, participou com aproveitamento do CURSO/EVENTO, <?php echo e(strtoupper($e->nome)); ?>, ministrado na modalidade a distância, de <?php echo e($e->data_inicio); ?> a <?php echo e($e->data_fim); ?>, com <?php echo e($e->carga_horaria); ?> horas-aula.
	</p>

	<p class="footer">
		<?php echo e($c->cidade); ?>, <?php echo e($c['data_hora']); ?><br>
		<strong><?php echo e($c->nome_responsavel); ?></strong><br>
		<?php echo e($c->cargo_responsavel); ?><br>
		<br><br>
		Originalmente emitido em <?php echo e(date('d/m/Y')); ?> às <?php echo e(date('H:i:s')); ?> - Código de autenticação: <?php echo e(strtoupper($c['codigo'])); ?>	
	</p>
</div>
