
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/datetimepicker/build/jquery.datetimepicker.min.css')); ?>">
<?php $__env->startSection('context'); ?>
    <div class="col-md-9">
        <div class="panel panel-default">
            <div class="panel-heading">Editar Novo Evento</div>
            <div class="panel-body">
            <?php echo Form::open(array('url' => 'evento/edit/'.$e->id, 'method' => 'PUT')); ?>

                    <?php if(Auth::user()->tipo != 'C'): ?>
                        <div class="form-group">
                            <?php echo Form::label('user_id', 'Coordenador do Evento');; ?>


                            <?php echo Form::select('user_id', $usuario, null, array('class' => 'form-control'));; ?>

                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                    	<?php echo Form::label('nome', 'Nome do Evento');; ?>


						<?php echo Form::text('nome', $e->nome, array('class' => 'form-control'));; ?>

                    </div>
                    <div class="form-group">
                    	<?php echo Form::label('status', 'Status');; ?>


						<?php echo Form::select('status', array('A' => 'Aberto', 'F' => 'Fechado'), $e->status, array('class' => 'form-control'));; ?>

                    </div>

                    <div class="form-group">
                    	<?php echo Form::label('carga_horaria', 'Carga Horaria');; ?>


						<?php echo Form::text('carga_horaria', $e->carga_horaria, array('class' => 'form-control', 'type' => 'number'));; ?>

                    </div>

                    <div class="form-group">
                    	<?php echo Form::label('data_inicio', 'Data de Inicio');; ?>


						<?php echo Form::text('data_inicio', $e->data_inicio, array('class' => 'form-control'));; ?>

                    </div>

                    <div class="form-group">
                    	<?php echo Form::label('data_fim', 'Data de Termino');; ?>


						<?php echo Form::text('data_fim', $e->data_fim, array('class' => 'form-control'));; ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::submit('Salvar', array('class' => 'btn btn-primary'));; ?>

                        <a class="btn btn-danger delete" href="<?php echo e(url('evento')); ?>">Voltar</a>

                        <?php echo Form::reset('Limpar', array('class' => 'btn btn-warning'));; ?>

                    </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('assets/datetimepicker/build/jquery.datetimepicker.full.min.js')); ?>" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript">
        $.datetimepicker.setLocale('pt');

        $(document).ready(function(){
            $('#data_inicio').datetimepicker({
                timepicker: false,
                format: 'd/m/Y'
            });

            $('#data_fim').datetimepicker({
                timepicker: false,
                format: 'd/m/Y'
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>