<?php $__env->startSection('context'); ?>
    <div class="col-md-9">
        <h2>Detalhes do Usuario</h2>

        <p>Matricula: <?php echo e($user->matricula); ?></p>
        <p>Nome: <?php echo e($user->nome); ?></p>
        <p>Email: <?php echo e($user->email); ?></p>
        <p>Rg: <?php echo e($user->rg); ?></p>
        <p>Cpf: <?php echo e($user->cpf); ?></p>
        <p>Tipo de Usuario: <?php echo e($user->tipo); ?></p>
    </div>
    <a class="btn btn-primary" href="<?php echo e(url('user')); ?>"style="margin-right:10px">Voltar</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>