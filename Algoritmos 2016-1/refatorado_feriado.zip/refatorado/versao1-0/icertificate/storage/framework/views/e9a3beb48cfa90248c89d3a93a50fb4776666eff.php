

<?php $__env->startSection('menu_options'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-offset-3 col-md-6 col-md-offset-3">
	        <div class="panel panel-default">
	            <div class="panel-heading">Area de Login</div>
	            <div class="panel-body">
					<?php echo Form::open(array('url' => 'login', 'method' => 'post')); ?>


					<div class="form-group">
					<?php echo Form::label('matricula', 'Matricula');; ?>


					<?php echo Form::text('matricula', null, array('class' => 'form-control'));; ?>

					</div>

					<div class="form-group">
					<?php echo Form::label('password', 'Senha');; ?>


					<?php echo Form::password('password', array('class' => 'form-control'));; ?>

					</div>

					<div class="form-group">
					<?php echo Form::submit('Login', array('class' => 'btn btn-primary'));; ?>


					<?php echo Form::reset('Limpar', array('class' => 'btn btn-warning'));; ?>

					</div>

					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
		<!---->
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>