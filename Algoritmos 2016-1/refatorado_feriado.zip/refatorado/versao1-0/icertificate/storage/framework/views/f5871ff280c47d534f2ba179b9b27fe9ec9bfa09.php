

<?php $__env->startSection('context'); ?>
<div class="col-md-9">
    <h2>Evento: <?php echo e($ps[0]->enome); ?></h2>
    <h3>Validar Frequência dos participantes</h3>
    <?php echo Form::open(array('url' => 'frequencia/add/'.$id, 'method' => 'post')); ?>

    <table class="table table-bordered">
    <caption class="text-center">Lista de Inscritos</caption>
        <thead>
            <tr>
                <td>Nome</td>
                <td>Matricula</td>
                <td>CPF</td>
                <td><p>Selecionar todos</p><input type="checkbox" id="selectall"/></td>
            </tr>
        </thead>
        <?php foreach($ps as $key => $p): ?>
            <tr>
                <td>
                    <?php echo e($p->nome); ?>


                </td>
                
                <td>
                    <?php echo e($p->matricula); ?>

                </td>

                <td>
                    <?php echo e($p->cpf); ?>

                </td>

                <td>
                    <input type="checkbox" class="case" name="case[<?php echo e($key); ?>]" value="<?php echo e($p->in_id); ?>"/>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <div class="form-group">
        <?php echo Form::label('descricao', 'Observações');; ?>


        <?php echo Form::textarea('descricao', null, array('class' => 'form-control'));; ?>

    </div>

    <div class="form-group">
        <?php echo Form::submit('Salvar', array('class' => 'btn btn-primary'));; ?>


        <?php echo Form::reset('Limpar', array('class' => 'btn btn-warning'));; ?>

    </div>
    <?php echo Form::close(); ?>

</div>

<script type="text/javascript">
    $(document).ready(function(){
        // add multiple select / deselect functionality
        $("#selectall").click(function () {
            if($("#selectall:checked").length == 1)
                $('.case').prop('checked', true);
            else
                $('.case').removeAttr('checked');
        });
        // if all checkbox are selected, check the selectall checkbox
        // and viceversa
        $(".case").click(function(){
            if($(".case").length == $(".case:checked").length) {
                $('#selectall').prop('checked', true);
            } else if($(".case:checked").length == 0){
                $('#selectall').removeAttr('checked');
            }
        }); 
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>