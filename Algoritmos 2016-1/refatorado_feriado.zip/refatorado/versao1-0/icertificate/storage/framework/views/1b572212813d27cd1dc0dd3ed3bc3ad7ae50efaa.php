

<?php $__env->startSection('menu_options'); ?>
<li><a href="<?php echo e(url('login')); ?>"><i class="glyphicon glyphicon-log-in"></i> Login</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!--ERRORS-->
<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <strong>Opa!</strong> Algum(ns) problema(s) nos dados:<br><br>
        <ul>
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>
<!--FIM ERRORS-->

<!--MENSAGENS-->
<?php if(isset($mensagem)): ?>
    <div class="alert alert-success">
        <strong><?php echo e($mensagem); ?></strong>
    </div>
<?php endif; ?>    
<!--FIM MENSAGENS-->

<div class="container">
	<div class="row-fluid">
		<h1 class="text-center">Seja bem vindo ao sistema de certificados!</h1>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>