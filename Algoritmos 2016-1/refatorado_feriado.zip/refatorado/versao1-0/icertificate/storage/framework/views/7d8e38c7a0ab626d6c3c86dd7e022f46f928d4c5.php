

<?php $__env->startSection('context'); ?>
<div class="col-md-9">

    <section>
        <div class="busca">
            <form class="form-inline">

                <h1>Buscar Eventos</h1>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <br>
                    <input type="text" class="form-control" style="width: 717px" id="descricao">
                </div>
                <br>
                <div class="form-group">
                    <?php echo Form::label('data_inicio', 'Data de Inicio');; ?>

                    <br>
                    <?php echo Form::date('data_inicio', null, array('class' => 'form-control'));; ?>

                </div>

                <div class="form-group">
                    <?php echo Form::label('data_fim', 'Data de Termino');; ?>

                    <br>
                    <?php echo Form::date('data_fim', null, array('class' => 'form-control'));; ?>

                </div>

                <div class ="form-group">
                    <?php echo Form::label('', 'Local');; ?>

                    <br>
                    <?php echo Form::select('tipo', array(), null, array('class' => 'form-control'));; ?>


                </div>
                <br><br>
                <a href="#" class="btn btn-primary" >Buscar</a>

                <a href="<?php echo e(url('evento/add')); ?>" id="myBtn" class="btn btn-primary" style="margin-left: 10%" >Adicionar</a>



                <div class="form-group">

                    <?php /*<input type="text" class="form-control" style="width: 717px" id="nome" placeholder="Nome">*/ ?>

                    <?php /*<a href></a href><button type="text" class="btn btn-primary">Buscar</button>*/ ?>
                    <?php /*<button type="submit" class="btn btn-primary">Adicionar</button>*/ ?>


                </div>
            </form>
        </div>
    </section>




    <h2>Lista de Eventos</h2>

    <table class="table table-bordered">
        <thead>
            <tr>
                <td>Nome</td>
                <td>Status</td>
                <td>Data</td>
                <td>Endereço</td>
                <td colspan="4">Ações</td>
            </tr>

        </thead>

        <?php foreach($eventos as $evento): ?>
            <tr>
                <td>
                    <?php echo e($evento->nome); ?>


                </td>
                <td>
                    <?php echo e($evento->status == 'A' ? 'Aberto' : 'Fechado'); ?>

                </td>
                <td>
                    <?php echo e($evento->data_inicio); ?> a <?php echo e($evento->data_fim); ?>

                </td>
                <td>
                    <a href="<?php echo e(url($endereco.$evento->slug)); ?>" target="_blank" class="btn btn-primary"><span class="glyphicon glyphicon-arrow-up"></span> Link</a>
                </td>

                <td>
                    <a class="btn btn-warning" href="<?php echo e(url('evento/edit/'.$evento->id)); ?>"><span class="glyphicon glyphicon-pencil"></span> Editar</a>
                </td>

                <?php /*<td>*/ ?>
                    <?php /*<a class="btn btn-warning" href="<?php echo e(url('frequencia/add/'.$evento->id)); ?>"><span class="glyphicon glyphicon-pencil"></span> Adicionar Frequencia</a>*/ ?>
                <?php /*</td>*/ ?>

                <td>
                    <a class="btn btn-primary" href="<?php echo e(url('evento/participantes/'.$evento->id)); ?>"> Ver Participantes </a>
                </td>
                <td>
                    <a class="btn btn-danger delete" id="btn-apagar" href="<?php echo e(url('evento/delete/'.$evento->id)); ?>"><span class="glyphicon glyphicon-trash"></span>  Excluir</a>
                </td>
            </tr>


        <?php endforeach; ?>
    </table>




</div>

<script type="text/javascript">
    $(document).ready(function(){
        $(".delete").click( function(event) {
            var apagar = confirm('Deseja realmente excluir este evento?');
            if (!apagar){
                // aqui vai a instrução para apagar registro
                event.preventDefault();

            }
        });
    });


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>