<style>
    .red{
        color:red;
    }
</style>
<?php $__env->startSection('context'); ?>
        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">Cadastrar Novo Usuario</div>
                <div class="panel-body">
                	<?php echo Form::open(array('url' => 'user/edit/'.$u->id, 'method' => 'put')); ?>


                        <div class="form-group">
                            <p>Campos com <span class="red"> * </span>são obrigatorios</p>

                            <?php echo Form::label('nome', 'Nome *');; ?>


							<?php echo Form::text('nome', $u->nome, array('class' => 'form-control'));; ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('cpf', 'Cpf *');; ?>


							<?php echo Form::text('cpf', $u->cpf, array('class' => 'form-control'));; ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('rg', 'RG *');; ?>


							<?php echo Form::text('rg', $u->rg, array('class' => 'form-control'));; ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::label('matricula', 'Matricula *');; ?>


							<?php echo Form::text('matricula', $u->matricula, array('class' => 'form-control'));; ?>

                        </div>

                        <div class ="form-group">
                        	<?php echo Form::label('tipo', 'Tipo de Usuario *');; ?>


							<?php echo Form::select('tipo', array('C' => 'Coordenador', 'G' => 'Gerente'), null, array('class' => 'form-control'));; ?>

                            
                        </div>

                        <div class="form-group">
                            <?php echo Form::label('email', 'Email *');; ?>


							<?php echo Form::text('email', $u->email, array('class' => 'form-control', 'required' => true));; ?>

                        </div>

                        <p>Mesma senha?</p>
                        <input checked name="mesma_senha" type="checkbox" id="mesma_senha"  >

                        <br /> <br>
                        <div id="div_senha">

                            <div class="form-group">
                                <?php echo Form::label('password', 'Nova Senha *');; ?>


                                <?php echo Form::password('password', array('class' => 'form-control'));; ?>

                            </div>

                            <div class="form-group">
                                <?php echo Form::label('password_confirmation', 'Confirme a nova senha *');; ?>


                                <?php echo Form::password('password_confirmation', array('class' => 'form-control'));; ?>

                            </div>
                        </div>

                    <div class="form-group">
                            <?php echo Form::submit('Salvar', array('class' => 'btn btn-primary'));; ?>


							<?php echo Form::reset('Limpar', array('class' => 'btn btn-warning'));; ?>

                        </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
    </div>
        <script type="text/javascript" src="<?php echo e(asset('assets/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js')); ?>">



        </script>
        <script type="text/javascript">
            $('#mesma_senha').click(function(){
                var tamanho = $('#mesma_senha:checked').length;
                if (tamanho == 0){
                    $("#div_senha").show();
                }else{
                    $("#div_senha").hide();
                }
                //alert($('#mesma_senha:checked').length);

            });
            $(document).ready(function(){
               //
                $("#div_senha").hide();

                $("#cpf").inputmask("999.999.999-99");
               //
            });
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>