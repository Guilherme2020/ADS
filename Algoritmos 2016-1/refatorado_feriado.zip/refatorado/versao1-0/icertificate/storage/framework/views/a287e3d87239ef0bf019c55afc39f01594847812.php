

<?php $__env->startSection('context'); ?>

    <section>
        <div class="busca">
            <form class="form-inline">

                <h1>Buscar Usuarios</h1>
                <div class="form-group">
                    <label for="matricula">Matricula:</label>
                    <br>
                    <input type="text" class="form-control" id="matricula">
                </div>
                <div class="form-group">
                    <label for="cpf">CPF:</label>
                    <br>
                    <input type="number" class="form-control" id="cpf">
                </div>

                <div class="form-group">
                    <label for="cpf">RG:</label>
                    <br>
                    <input type="number" class="form-control" id="rg">
                </div>
                <div class ="form-group">
                    <?php echo Form::label('tipo', 'Tipo de Usuario');; ?>

                    <br>
                    <?php echo Form::select('tipo', array('C' => 'Coordenador', 'G' => 'Gerente','D' => "Direx"), null, array('class' => 'form-control'));; ?>


                </div>
                <br><br>
                <div class="form-group">
                    <label for="Nome">Nome</label>
                    <br>
                    <input type="text" class="form-control" style="width: 717px" id="nome" placeholder="Nome">
                    <br><br>
                    <?php /*<a href></a href><button type="text" class="btn btn-primary">Buscar</button>*/ ?>
                    <?php /*<button type="submit" class="btn btn-primary">Adicionar</button>*/ ?>

                    <a href="#" class="btn btn-primary" >Buscar</a>

                    <a href="<?php echo e(url('user/add')); ?>" id="myBtn" class="btn btn-primary" style="margin-left: 10%" >Adicionar</a>

                </div>

            </form>
        </div>
    </section>

    <!-- Trigger/Open The Modal -->

    <!-- The Modal -->
    <div id="myModal" class="modal">

        <!-- Modal content -->
        <div class="modal-content">
            <span class="close">x</span>
            <p>HHAHA..</p>
        </div>

    </div>

    <style>
        /* The Modal (background) */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

        /* Modal Content/Box */
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 80%; /* Could be more or less, depending on screen size */
        }

        /* The Close Button */
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>
    <script>
        // Get the modal
        var modal = document.getElementById('myModal');

        // Get the button that opens the modal
        var btn = document.getElementById("myBtn");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks on the button, open the modal
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

    </script>

    <div class="col-md-9">

        <br>

    <table class="table table-bordered">
        <thead>
            <tr>

                <td>Nome</td>
                <td>Matricula</td>
                <td>Email</td>
                <td>Tipo de Usuario</td>
                <td colspan="3">Ações</td>
            </tr>

        </thead>

        <?php foreach($users as $user): ?>
            <tr>
                <td>
                    <?php echo e($user->nome); ?>


                </td>
                <td>
                    <?php echo e($user->matricula); ?>

                </td>

                <td>
                    <?php echo e($user->email); ?>

                </td>
                <td>
                    <?php echo e($user->tipo); ?>

                </td>
                <td>
                    <a class="btn btn-warning" href="<?php echo e(url('user/edit/'.$user->id)); ?>"><span class="glyphicon glyphicon-pencil"></span> Editar</a>
                </td>
                <td>
                    <a class="btn btn-primary" href="<?php echo e(url('user/view/'.$user->id)); ?>"><span class="glyphicon glyphicon-search"></span> Ver </a>
                </td>
                <td>
                    <a class="btn btn-danger delete" href="<?php echo e(url('user/delete/'.$user->id)); ?>"><span class="glyphicon glyphicon-trash"></span>  Excluir</a>
                </td>
            </tr>


        <?php endforeach; ?>
    </table>
</div>

    <script type="text/javascript" src="<?php echo e(asset('assets/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js')); ?>"></script>


    <script type="text/javascript">
        $(document).ready(function(){
            //
            $("#cpf").inputmask("999.999.999-99");
            //
        });
    </script>


  <script type="text/javascript">
  $(document).ready(function(){
     $(".delete").on("click", function(event) {
        var apagar = confirm('Deseja realmente excluir este registro de Usuario?');
        if (!apagar){
  	// aqui vai a instrução para apagar registro
          event.preventDefault();
        }
     });
  });

  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>