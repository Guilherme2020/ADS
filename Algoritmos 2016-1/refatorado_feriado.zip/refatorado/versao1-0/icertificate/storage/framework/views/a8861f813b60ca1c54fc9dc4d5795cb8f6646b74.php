<?php $__env->startSection('context'); ?>
<div class="col-md-9">
    <h2>Lista de Participantes do Evento: <?php echo e($e->nome); ?></h2>

    <table class="table table-bordered">
        <thead>
            <tr>
                <td>Nome</td>
                <td>Email</td>
                <td>CPF</td>
                <td>Matricula</td>
                <td colspan="4">Ações</td>
            </tr>

        </thead>

        <?php foreach($ps as $p): ?>
            <tr>
                <td>
                    <?php echo e($p->nome); ?>

                </td>
                <td>
                    <?php echo e($p->email); ?>

                </td>
                <td>
                    <?php echo e($p->cpf); ?>

                </td>
                
                <td>
                    <a class="btn btn-warning" href="<?php echo e(url('participante/edit/'.$p->id)); ?>"><span class="glyphicon glyphicon-pencil"></span> Editar</a>
                </td>

                <td>
                    <a class="btn btn-danger" href="<?php echo e(url('evento/deleteInscricao/'.$p->in_id)); ?>"><span class="glyphicon glyphicon-trash"></span>  Excluir</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>