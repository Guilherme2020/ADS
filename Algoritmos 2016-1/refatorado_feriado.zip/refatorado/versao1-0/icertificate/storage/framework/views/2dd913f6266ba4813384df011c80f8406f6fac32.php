

<?php $__env->startSection('context'); ?>
<div class="col-md-9">
    <h2>Definições de Configurações</h2>
    
    <span>
    	<p><strong>Instituição:</strong> <?php echo e($c->instituicao); ?></p>
    	<p><strong>Cidade:</strong> <?php echo e($c->cidade); ?></p>
    	<p><strong>Estado:</strong> <?php echo e($c->estado); ?></p>
    	<p><strong>Nome do Superior:</strong> <?php echo e($c->nome_superior); ?></p>
    	<p><strong>Cargo do Superior:</strong> <?php echo e($c->cargo_superior); ?></p>
    	<p><strong>Nome do Responsavel:</strong> <?php echo e($c->nome_responsavel); ?></p>
    	<p><strong>Cargo do Responsavel:</strong> <?php echo e($c->cargo_responsavel); ?></p>
    	<p><strong>Setor Responsavel:</strong> <?php echo e($c->setor); ?></p>
    </span>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>