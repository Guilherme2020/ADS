<?php $__env->startSection('context'); ?>
<h2 class="text-center">Seja bem vindo(a), <?php echo e(Auth::user()->nome); ?></h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>