
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->startSection('context'); ?>
<div class="col-md-9">
    <h2>Lista de Participantes por evento</h2>

    <?php foreach($es as $e): ?>
    <h3 class="text-center">Nome: <?php echo e($e->nome); ?></h3>
    <table class="display table table-hover table-responsive" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Cpf</th>
                <th>Matricula</th>
                <th>Email</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>Nome</th>
                <th>Cpf</th>
                <th>Matricula</th>
                <th>Email</th>
                <th>Ações</th>
            </tr>
        </tfoot>
        <tbody>
            <?php foreach($e->ps as $p): ?>
            <tr>
                <td><?php echo e($p->nome); ?></td>
                <td><?php echo e($p->cpf); ?></td>
                <td><?php echo e($p->matricula); ?></td>
                <td><?php echo e($p->email); ?></td>
                <td><a target="_blank" href="<?php echo e(url('participante/certificado/'.$p->in_id)); ?>" class="btn btn-primary">Ver certificado</a>
                <a href="<?php echo e(url('participante/enviar/'.$p->in_id)); ?>" class="btn btn-primary">Enviar por email</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>    
    </table>

    <a target="_blank" href="<?php echo e(url('evento/frequencia/'.$e->id)); ?>" class="btn btn-primary">Ver lista de frequencia</a>

    <a target="_blank" href="<?php echo e(url('evento/certificados/'.$e->id)); ?>" class="btn btn-primary">Ver Todos os certificados</a>

    <?php endforeach; ?>
    <!---->
</div>
<script src="<?php echo e(asset('assets/datatables.net/js/jquery.dataTables.min.js')); ?>" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo e(asset('assets/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.display').DataTable( {
            "order": [[ 0, "desc" ]],
            "language": {
                "url": "<?php echo e(asset('assets/datatables.pt-br.json')); ?>"
            }
        });
    } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>