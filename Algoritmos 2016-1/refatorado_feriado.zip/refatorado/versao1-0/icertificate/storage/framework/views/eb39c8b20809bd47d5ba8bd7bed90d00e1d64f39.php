
<?php $__env->startSection('context'); ?>
    <div class="col-md-9">
        <div class="panel panel-default">
            <div class="panel-heading">Definição de Configurações</div>
            <div class="panel-body">
            <?php echo Form::open(array('url' => 'configuracao/add', 'method' => 'post')); ?>

                    <div class="form-group">
                    	<?php echo Form::label('instituicao', 'Instituicao');; ?>


						<?php echo Form::text('instituicao', $c->instituicao, array('class' => 'form-control'));; ?>

                    </div>
                    
                    <div class="form-group">
                        <?php echo Form::label('cidade', 'Cidade');; ?>


                        <?php echo Form::text('cidade', $c->cidade, array('class' => 'form-control'));; ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('estado', 'Estado');; ?>


                        <?php echo Form::text('estado', $c->estado, array('class' => 'form-control'));; ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('nome_superior', 'Nome do Superior');; ?>


                        <?php echo Form::text('nome_superior', $c->nome_superior, array('class' => 'form-control'));; ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('cargo_superior', 'Cargo do Superior');; ?>


                        <?php echo Form::text('cargo_superior', $c->cargo_superior, array('class' => 'form-control'));; ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('nome_responsavel', 'Nome do Responsavel');; ?>


                        <?php echo Form::text('nome_responsavel', $c->nome_responsavel, array('class' => 'form-control'));; ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('cargo_responsavel', 'Cargo do Responsavel');; ?>


                        <?php echo Form::text('cargo_responsavel', $c->cargo_responsavel, array('class' => 'form-control'));; ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('setor', 'Setor Responsavel');; ?>


                        <?php echo Form::text('setor', $c->setor, array('class' => 'form-control'));; ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::submit('Salvar', array('class' => 'btn btn-primary'));; ?>


						<?php echo Form::reset('Limpar', array('class' => 'btn btn-warning'));; ?>

                    </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.'.Session::get('layout'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>