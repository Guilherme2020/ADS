<style type="text/css">
	body{
		/**background-image: url({{ asset('img/modelo_certificado.fw.png') }});
		background-position: top left;
	    background-repeat: no-repeat;
	    background-size: 100%;*/

	    padding: 0px 0px 0px 0px;
	}

	.page { 
		border: 7px solid green;
		/*border: 1px solid black;*/
	}

	.title{
		text-align: center;
		font-family: Times;
		font-size: 60pt;
		text-transform: bold;
		margin-top: 80px; 
	}

	.main{
		text-align: justify;
		font-family: Verdana;
		margin-left: 50px;
		margin-right: 50px;
		font-size: 14pt;
		margin-top: 140px;
	}

	.footer{
		text-align: center;
		font-family: Verdana;
		font-size: 12pt;	
		margin-top: 80px;
	}
</style>
@foreach($ps as $p)
<div class="page">
	<p class="title">
		Certificado
	</p>

	<p class="main">
		A {{ $c->setor }} do {{ $c->instituicao }} certifica que {{ strtoupper($p->nome) }}, CPF
		{{ $p->cpf }}, participou com aproveitamento do CURSO {{ strtoupper($e->nome) }}, ministrado na modalidade a distância, de {{ $e->data_inicio }} a {{ $e->data_fim }}, com {{ $e->carga_horaria }} horas-aula.
	</p>

	<p class="footer">
		{{ $c->cidade }}, {{ $c['data_hora'] }}<br>
		<strong>{{ $c->nome_responsavel }}</strong><br>
		{{ $c->cargo_responsavel }}<br>
		<br><br>
		Originalmente emitido em {{ date('d/m/Y') }} às {{ date('H:i:s') }} - Código de autenticação: {{ strtoupper($c['codigo']) }}	
	</p>
</div>
@endforeach