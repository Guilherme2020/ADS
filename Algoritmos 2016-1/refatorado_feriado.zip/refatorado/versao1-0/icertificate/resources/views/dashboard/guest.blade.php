@extends('layouts.main')

@section('menu_options')
<li><a href="{{ url('login') }}"><i class="glyphicon glyphicon-log-in"></i> Login</a></li>
@endsection

@section('content')

<!--ERRORS-->
@if (count($errors) > 0)
    <div class="alert alert-danger">
        <strong>Opa!</strong> Algum(ns) problema(s) nos dados:<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<!--FIM ERRORS-->

<!--MENSAGENS-->
@if(isset($mensagem))
    <div class="alert alert-success">
        <strong>{{ $mensagem }}</strong>
    </div>
@endif    
<!--FIM MENSAGENS-->

<div class="container">
	<div class="row-fluid">
		<h1 class="text-center">Seja bem vindo ao sistema de certificados!</h1>
	</div>
</div>
@endsection