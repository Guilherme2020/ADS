@extends('layouts.coordenador')

@section('menu_options')
<li class="dropdown">
    <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#"><i class="glyphicon glyphicon-user"></i> {{ explode(" ", Auth::user()->nome)[0] }} <span class="caret"></span></a>
    <ul id="g-account-menu" class="dropdown-menu" role="menu">
        <li><a href="{{ url('user/edit') }}">Perfil</a></li>
        <li><a href="{{ url('logout') }}"><i class="glyphicon glyphicon-log-out"></i> Logout</a></li>
    </ul>
</li>
@endsection

@section('content')


<!-- Main -->
<div class="container-fluid">
    <div class="row-fluid">
        {{--<div class="col-sm-3">--}}
            {{--<!-- Left column -->--}}
            {{--<!-- <a href="#"><strong><i class="glyphicon glyphicon-wrench"></i> Atividades</strong></a>--}}
             {{---->--}}
             {{--<hr>--}}

            {{--<ul class="nav nav-stacked">--}}
                {{----}}
                {{--<li class="nav-header"><a href="{{ Auth::user() ? url('/dashboard') : '#' }}">Home</li></a>--}}

                {{--<!-- <li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#userMenu">Cadastros <i class="glyphicon glyphicon-chevron-down"></i></a> -->--}}
                    {{----}}
                {{--<!-- <li><a href="#"><i class="glyphicon glyphicon-envelope"></i> Meus Eventos <span class="badge badge-info"></span></a></li>   --}}
                 {{---->    --}}
                 {{--<!-- <ul class="nav nav-stacked collapse in" id="userMenu">--}}
                  {{---->       <!--<li class="active"> <a href="{{ url('user/add') }}"><i class="glyphicon glyphicon-home"></i> Usuario</a></li>-->--}}
                        {{----}}
                   {{--<!--  </ul>--}}
                {{--</li> -->--}}
                {{--<li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#menu2"> Consultas <i class="glyphicon glyphicon-chevron-right"></i></a>--}}

                    {{--<ul class="nav nav-stacked collapse" id="menu2">--}}
                        {{--<!-- <li><a href="{{ url('evento') }}">Eventos</a></li>--}}
                         {{---->--}}
                         {{--<li><a href="#">Meus Eventos</a></li>--}}
                        {{--<!--<li><a href="{{ url('user') }}">Usuarios</a>--}}
                        {{--</li>-->--}}
                        {{----}}
                        {{--<!-- <li><a href="{{ url('participante') }}">Participantes</a></li>--}}
                         {{---->--}}
                         {{--<li><a href="#">Participantes</a></li>--}}
                    {{----}}

                    {{--</ul>--}}
                {{--</li>--}}
                {{--<li class="nav-header"><a href="#">Frequencia</li></a>--}}
                {{--<li class="nav-header">--}}
                    {{--<a href="#" data-toggle="collapse" data-target="#menu3"> Atividades <i class="glyphicon glyphicon-chevron-right"></i></a>--}}
                    {{--<ul class="nav nav-stacked collapse" id="menu3">--}}
                        {{--<!-- <li><a target="_blank" href="{{ url('evento/eventos_abertos') }}"><i class="glyphicon glyphicon-circle"></i> Meus Eventos Abertos</a></li>--}}
                         {{---->--}}
                         {{--<li><a  href="#"><i class="glyphicon glyphicon-circle"></i> Meus Eventos Abertos</a></li>--}}
                        {{--<!-- <li><a target="_blank" href="{{ url('evento/participantes_evento') }}"><i class="glyphicon glyphicon-circle"></i> Participantes por evento</a></li>--}}
                     {{---->--}}
                         {{--<li><a  href="#"><i class="glyphicon glyphicon-circle"></i> Participantes por evento</a></li>--}}
                    {{--</ul>--}}
                {{--</li>--}}
            {{--</ul>--}}
            {{--<hr>--}}
            {{--<!-- End Left column -->--}}
        {{--</div>--}}
        @yield('context')
        <!-- /col-3 -->
    </div>
</div>
<!-- /Main -->
@endsection