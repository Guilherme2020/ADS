@extends('layouts.gerente')
@section('menu_options')
<li class="dropdown">
    <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#"><i class="glyphicon glyphicon-user"></i> {{ explode(" ", Auth::user()->nome)[0] }} <span class="caret"></span></a>
    <ul id="g-account-menu" class="dropdown-menu" role="menu">
        <li><a href="{{ url('user/edit') }}">Perfil</a></li>
        <li><a href="{{ url('logout') }}"><i class="glyphicon glyphicon-log-out"></i> Logout</a></li>
    </ul>
</li>
@endsection

@section('content')
<!-- Main -->
<div class="container-fluid">
    <div class="row-fluid">
        {{--<div class="col-sm-3">--}}
            {{--<!-- Left column -->--}}
            {{--<hr>--}}

            {{--<ul class="nav nav-stacked">--}}

                {{--<li class="nav-header"><a href="{{ Auth::user() ? url('/dashboard') : '#' }}">Home</li></a>--}}

                {{--<li class="nav-header"><a href="{{ url('evento/add') }}">Cadastrar Evento</li></a>--}}

               {{--<li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#userMenu">Cadastros <i class="glyphicon glyphicon-chevron-down"></i></a>--}}
                    {{--<ul class="nav nav-stacked collapse in" id="userMenu">--}}
                        {{--<li class="active"> <a href="{{ url('user/add') }}"><i class="glyphicon glyphicon-home"></i>Cadastrar Usuario</a></li>--}}
                        {{--<li><a href="{{ url('evento/add') }}"><i class="glyphicon glyphicon-envelope"></i> Cadastrar Evento <span class="badge badge-info">4</span></a></li>--}}
                    {{--</ul>--}}
                {{--</li>--}}

                {{--<li class="nav-header"><a href="#">Frequencia</li></a>--}}

                {{--<li class="nav-header">--}}

                {{--<li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#menu2"> Usuarios <i class="glyphicon glyphicon-chevron-right"></i></a>--}}

                    {{--<ul class="nav nav-stacked collapse" id="menu2">--}}
                        {{--<li><a href="{{ url('evento') }}"> Lista de Eventos</a></li>--}}

                        {{--<li class="nav-header"><a href="{{ url('user/add') }} ">Cadastrar Usuario</li></a>--}}


                        {{--<li><a href="{{ url('user') }}">Listar Usuarios</a>--}}
                        {{--</li>--}}
                        {{--<!-- <li><a href="{{ url('evento/participantes') }}">Participantes</a></li>--}}
                         {{---->--}}


                    {{--</ul>--}}
                {{--</li>--}}



                {{--<!-- <li class="nav-header"> <a href="#" data-toggle="collapse" data-target="#menu2"> Consultas <i class="glyphicon glyphicon-chevron-right"></i></a>--}}
 {{---->--}}
                    {{--<!-- <ul class="nav nav-stacked collapse" id="menu2">--}}
                     {{---->    <!-- <li><a href="{{ url('evento') }}"> Eventos</a>--}}
                        {{--</li>--}}
                         {{---->--}}
                        {{--<!--  <li><a href="#"> Eventos</a></li>--}}
                         {{----><!----}}
                        {{--<li><a href="{{ url('user') }}"> Usuarios</a></li> -->--}}
                        {{--<!-- <li><a href="{{ url('evento/participantes') }}">Participantes</a></li>--}}
                         {{----><!----}}
                         {{--<li><a href="#">Participantes</a></li>--}}
                     {{---->--}}
                    {{--<!-- </ul> -->--}}
                {{--<!-- </li> -->--}}
                {{--<li class="nav-header">--}}
                    {{--<a href="#" data-toggle="collapse" data-target="#menu3"> Atividades <i class="glyphicon glyphicon-chevron-right"></i></a>--}}
                    {{--<ul class="nav nav-stacked collapse" id="menu3">--}}
                        {{--<!-- <li><a target="_blank" href="{{ url('evento/eventos_abertos') }}"><i class="glyphicon glyphicon-circle"></i> Eventos Abertos</a></li>--}}
                         {{---->--}}
                         {{--<li><a  href="#"><i class="glyphicon glyphicon-circle"></i> Eventos Abertos</a></li>--}}

                       {{--<!--  <li><a target="_blank" href="{{ url('evento/participantes_evento') }}"><i class="glyphicon glyphicon-circle"></i> Participantes por evento</a></li>--}}
                     {{---->--}}
                     {{--<li><a  href="#"><i class="glyphicon glyphicon-circle"></i> Participantes por evento</a></li>--}}

                    {{--</ul>--}}
                {{--</li>--}}
            {{--</ul>--}}
            {{--<hr>--}}
            {{--<!-- End Left column -->--}}
        {{--</div>--}}
        @yield('context')
        <!-- /col-3 -->
    </div>
</div>
<!-- /Main -->
@endsection