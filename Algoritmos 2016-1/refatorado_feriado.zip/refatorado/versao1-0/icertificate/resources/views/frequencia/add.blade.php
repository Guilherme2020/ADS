@extends('dashboard.'.Session::get('layout'))

@section('context')
<div class="col-md-9">
    <h2>Evento: {{ $ps[0]->enome }}</h2>
    <h3>Validar Frequência dos participantes</h3>
    {!! Form::open(array('url' => 'frequencia/add/'.$id, 'method' => 'post')) !!}
    <table class="table table-bordered">
    <caption class="text-center">Lista de Inscritos</caption>
        <thead>
            <tr>
                <td>Nome</td>
                <td>Matricula</td>
                <td>CPF</td>
                <td><p>Selecionar todos</p><input type="checkbox" id="selectall"/></td>
            </tr>
        </thead>
        @foreach($ps as $key => $p)
            <tr>
                <td>
                    {{ $p->nome }}

                </td>
                
                <td>
                    {{ $p->matricula }}
                </td>

                <td>
                    {{ $p->cpf }}
                </td>

                <td>
                    <input type="checkbox" class="case" name="case[{{ $key }}]" value="{{ $p->in_id }}"/>
                </td>
            </tr>
        @endforeach
    </table>

    <div class="form-group">
        {!! Form::label('descricao', 'Observações'); !!}

        {!! Form::textarea('descricao', null, array('class' => 'form-control')); !!}
    </div>

    <div class="form-group">
        {!! Form::submit('Salvar', array('class' => 'btn btn-primary')); !!}

        {!! Form::reset('Limpar', array('class' => 'btn btn-warning')); !!}
    </div>
    {!! Form::close() !!}
</div>

<script type="text/javascript">
    $(document).ready(function(){
        // add multiple select / deselect functionality
        $("#selectall").click(function () {
            if($("#selectall:checked").length == 1)
                $('.case').prop('checked', true);
            else
                $('.case').removeAttr('checked');
        });
        // if all checkbox are selected, check the selectall checkbox
        // and viceversa
        $(".case").click(function(){
            if($(".case").length == $(".case:checked").length) {
                $('#selectall').prop('checked', true);
            } else if($(".case:checked").length == 0){
                $('#selectall').removeAttr('checked');
            }
        }); 
    });
</script>

@endsection