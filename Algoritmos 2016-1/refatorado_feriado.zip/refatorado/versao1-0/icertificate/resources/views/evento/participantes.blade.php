@extends('dashboard.'.Session::get('layout'))

@section('context')
<div class="col-md-9">
    <h2>Lista de Participantes do Evento: {{ $e->nome }}</h2>

    <table class="table table-bordered">
        <thead>
            <tr>
                <td>Nome</td>
                <td>Email</td>
                <td>CPF</td>
                <td>Matricula</td>
                <td colspan="4">Ações</td>
            </tr>

        </thead>

        @foreach($ps as $p)
            <tr>
                <td>
                    {{$p->nome}}
                </td>
                <td>
                    {{$p->email}}
                </td>
                <td>
                    {{$p->cpf}}
                </td>
                
                <td>
                    <a class="btn btn-warning" href="{{ url('participante/edit/'.$p->id) }}"><span class="glyphicon glyphicon-pencil"></span> Editar</a>
                </td>

                <td>
                    <a class="btn btn-danger" href="{{ url('evento/deleteInscricao/'.$p->in_id) }}"><span class="glyphicon glyphicon-trash"></span>  Excluir</a>
                </td>
            </tr>
        @endforeach
    </table>
</div>
@endsection