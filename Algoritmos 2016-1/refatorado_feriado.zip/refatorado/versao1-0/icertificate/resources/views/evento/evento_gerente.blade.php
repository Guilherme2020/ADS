@extends('dashboard.'.Session::get('layout'))
<link rel="stylesheet" type="text/css" href="{{ asset('assets/datatables.net-bs/css/dataTables.bootstrap.min.css') }}">
@section('context')
    <div class="col-md-9">
        <h2>Lista de Participantes por evento</h2>

        @foreach($es as $e)
            <h3 class="text-center">Nome: {{$e->nome}}</h3>
            <table class="display table table-hover table-responsive" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th>Nome</th>
                    <th>Cpf</th>
                    <th>Matricula</th>
                    <th>Email</th>
                    <th>Ações</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th>Nome</th>
                    <th>Cpf</th>
                    <th>Matricula</th>
                    <th>Email</th>
                    <th>Ações</th>
                </tr>
                </tfoot>
                <tbody>
                @foreach($e->ps as $p)
                    <tr>
                        <td>{{ $p->nome }}</td>
                        <td>{{ $p->cpf }}</td>
                        <td>{{ $p->matricula }}</td>
                        <td>{{ $p->email }}</td>
                        <td><a target="_blank" href="{{ url('participante/certificado/'.$p->in_id) }}" class="btn btn-primary">Ver certificado</a>
                            <a href="#" class="btn btn-primary">Enviar por email</a>
                        

                            <!-- <a href="{{ url('participante/enviar/'.$p->in_id) }}" class="btn btn-primary">Enviar por email</a> -->
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>

            <a target="_blank" href="{{ url('evento/frequencia/'.$e->id) }}" class="btn btn-primary">Ver lista de frequencia</a>

            <a target="_blank" href="{{ url('evento/certificados/'.$e->id) }}" class="btn btn-primary">Ver  certificao geral</a>

            @endforeach
                    <!---->
    </div>
    <script src="{{ asset('assets/datatables.net/js/jquery.dataTables.min.js') }}" type="text/javascript" charset="utf-8"></script>
    <script src="{{ asset('assets/datatables.net-bs/js/dataTables.bootstrap.min.js') }}" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.display').DataTable( {
                "order": [[ 0, "desc" ]],
                "language": {
                    "url": "{{ asset('assets/datatables.pt-br.json') }}"
                }
            });
        } );
    </script>
@endsection