<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-15">
<style>
body { 
	font-family: verdana, sans-serif;
} 
table {
  margin-bottom: 2em;
  width: 100%;
  
}

thead {
  
}

tbody {
  
}

th,td {
  text-align: center;
  padding: 1pt;
}

table {
  
}

table td.assin {
  border-bottom: 1pt solid black;
  width: 35%;
}

.head{
	text-align: center;
}
</style>
</head>
<body>
<!---->
	<div class="head">
		<h2>Lista de Eventos Abertos</h2>
	</div>
<!---->
<table> 
<thead>
  <tr>
    <th>Nome</th>
    <th>Data</th>
    <th>Link</th>
  </tr>
</thead>
  <tbody>
@foreach($ps as $e)
  <tr>
    <td>{{ $e->nome }}</td>
    <td>{{ $e->data_inicio }} a {{ $e->data_inicio }}</td>
    <td><a href="{{ url('evento/cadastro/'.$e->slug) }}">Link</a></td>
  </tr>
@endforeach
  </tbody>
</table>
</body>
</html>