@extends('dashboard.'.Session::get('layout'))

@section('context')
<div class="col-md-9">

    <section>
        <div class="busca">
            <form class="form-inline">

                <h1>Buscar Eventos</h1>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <br>
                    <input type="text" class="form-control" style="width: 717px" id="descricao">
                </div>
                <br>
                <div class="form-group">
                    {!! Form::label('data_inicio', 'Data de Inicio'); !!}
                    <br>
                    {!! Form::date('data_inicio', null, array('class' => 'form-control')); !!}
                </div>

                <div class="form-group">
                    {!! Form::label('data_fim', 'Data de Termino'); !!}
                    <br>
                    {!! Form::date('data_fim', null, array('class' => 'form-control')); !!}
                </div>

                <div class ="form-group">
                    {!! Form::label('', 'Local'); !!}
                    <br>
                    {!! Form::select('tipo', array(), null, array('class' => 'form-control')); !!}

                </div>
                <br><br>
                <a href="#" class="btn btn-primary" >Buscar</a>

                <a href="{{url('evento/add')}}" id="myBtn" class="btn btn-primary" style="margin-left: 10%" >Adicionar</a>



                <div class="form-group">

                    {{--<input type="text" class="form-control" style="width: 717px" id="nome" placeholder="Nome">--}}

                    {{--<a href></a href><button type="text" class="btn btn-primary">Buscar</button>--}}
                    {{--<button type="submit" class="btn btn-primary">Adicionar</button>--}}


                </div>
            </form>
        </div>
    </section>




    <h2>Lista de Eventos</h2>

    <table class="table table-bordered">
        <thead>
            <tr>
                <td>Nome</td>
                <td>Status</td>
                <td>Data</td>
                <td>Endereço</td>
                <td colspan="4">Ações</td>
            </tr>

        </thead>

        @foreach($eventos as $evento)
            <tr>
                <td>
                    {{$evento->nome}}

                </td>
                <td>
                    {{ $evento->status == 'A' ? 'Aberto' : 'Fechado'}}
                </td>
                <td>
                    {{$evento->data_inicio}} a {{$evento->data_fim}}
                </td>
                <td>
                    <a href="{{ url($endereco.$evento->slug) }}" target="_blank" class="btn btn-primary"><span class="glyphicon glyphicon-arrow-up"></span> Link</a>
                </td>

                <td>
                    <a class="btn btn-warning" href="{{ url('evento/edit/'.$evento->id) }}"><span class="glyphicon glyphicon-pencil"></span> Editar</a>
                </td>

                {{--<td>--}}
                    {{--<a class="btn btn-warning" href="{{ url('frequencia/add/'.$evento->id) }}"><span class="glyphicon glyphicon-pencil"></span> Adicionar Frequencia</a>--}}
                {{--</td>--}}

                <td>
                    <a class="btn btn-primary" href="{{ url('evento/participantes/'.$evento->id) }}"> Ver Participantes </a>
                </td>
                <td>
                    <a class="btn btn-danger delete" id="btn-apagar" href="{{ url('evento/delete/'.$evento->id) }}"><span class="glyphicon glyphicon-trash"></span>  Excluir</a>
                </td>
            </tr>


        @endforeach
    </table>




</div>

<script type="text/javascript">
    $(document).ready(function(){
        $(".delete").click( function(event) {
            var apagar = confirm('Deseja realmente excluir este evento?');
            if (!apagar){
                // aqui vai a instrução para apagar registro
                event.preventDefault();

            }
        });
    });


</script>
@endsection