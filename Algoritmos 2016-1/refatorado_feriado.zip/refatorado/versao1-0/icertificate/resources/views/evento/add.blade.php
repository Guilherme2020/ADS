@extends('dashboard.'.Session::get('layout'))
<link rel="stylesheet" type="text/css" href="{{ asset('assets/datetimepicker/build/jquery.datetimepicker.min.css') }}">
@section('context')
    <div class="col-md-9">
        <div class="panel panel-default">
            <div class="panel-heading">Cadastrar Novo Evento</div>
            <div class="panel-body">
            {!! Form::open(array('url' => 'evento/add', 'method' => 'post')) !!}
                    @if(Auth::user()->tipo != 'C')
                        <div class="form-group">
                        	{!! Form::label('user_id', 'Coordenador do Evento'); !!}

							{!! Form::select('user_id', $usuario, null, array('class' => 'form-control')); !!}
                        </div>
                    @endif
                    <div class="form-group">
                    	{!! Form::label('nome', 'Nome do Evento'); !!}

						{!! Form::text('nome', null, array('class' => 'form-control')); !!}
                    </div>
                    <div class="form-group">
                    	{!! Form::label('status', 'Status'); !!}

						{!! Form::select('status', array('A' => 'Aberto', 'F' => 'Fechado'), null, array('class' => 'form-control')); !!}
                    </div>

                    <div class="form-group">
                    	{!! Form::label('carga_horaria', 'Carga Horaria'); !!}

						{!! Form::text('carga_horaria', null, array('class' => 'form-control', 'type' => 'number', 'min' => 0)); !!}
                    </div>

                    <div class="form-group">
                    	{!! Form::label('data_inicio', 'Data de Inicio'); !!}

						{!! Form::text('data_inicio', null, array('class' => 'form-control')); !!}
                    </div>

                    <div class="form-group">
                    	{!! Form::label('data_fim', 'Data de Termino'); !!}

						{!! Form::text('data_fim', null, array('class' => 'form-control')); !!}
                    </div>

                    <div class="form-group">
                        {!! Form::submit('Salvar', array('class' => 'btn btn-primary')); !!}
                        <a class="btn btn-danger delete" href="{{ url('evento')}}">Voltar</a>

                        {!! Form::reset('Limpar', array('class' => 'btn btn-warning')); !!}
                    </div>

                {!! Form::close() !!}
            </div>
        </div>
    </div>
    <script src="{{ asset('assets/datetimepicker/build/jquery.datetimepicker.full.min.js') }}" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript">
        $.datetimepicker.setLocale('pt');

        $(document).ready(function(){
            $('#data_inicio').datetimepicker({
                timepicker: false,
                format: 'd/m/Y'
            });

            $('#data_fim').datetimepicker({
                timepicker: false,
                format: 'd/m/Y'
            });

        });
    </script>
@endsection
