@extends('dashboard.'.Session::get('layout'))
<style>
    .red{
        color:red;
    }
</style>
@section('context')
        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">Cadastrar Novo Usuario</div>
                <div class="panel-body">
                	{!! Form::open(array('url' => 'user/edit/'.$u->id, 'method' => 'put')) !!}

                        <div class="form-group">
                            <p>Campos com <span class="red"> * </span>são obrigatorios</p>

                            {!! Form::label('nome', 'Nome *'); !!}

							               {!! Form::text('nome', $u->nome, array('class' => 'form-control')); !!}
                        </div>
                        <div class="form-group">
                            {!! Form::label('cpf', 'Cpf *'); !!}

							              {!! Form::text('cpf', $u->cpf, array('class' => 'form-control')); !!}
                        </div>
                        <div class="form-group">
                            {!! Form::label('rg', 'RG *'); !!}

							              {!! Form::text('rg', $u->rg, array('class' => 'form-control')); !!}
                        </div>

                        <div class="form-group">
                            {!! Form::label('matricula', 'Matricula *'); !!}

							              {!! Form::text('matricula', $u->matricula, array('class' => 'form-control')); !!}
                        </div>

                        <div class ="form-group">
                          	{!! Form::label('tipo', 'Tipo de Usuario *'); !!}

  							            {!! Form::select('tipo', array('C' => 'Coordenador', 'G' => 'Gerente'), null, array('class' => 'form-control')); !!}
                        </div>

                        <div class="form-group">
                            {!! Form::label('email', 'Email *'); !!}

							              {!! Form::text('email', $u->email, array('class' => 'form-control', 'required' => true)); !!}
                        </div>

                        <p>Mesma senha?</p>
                        <input checked name="mesma_senha" type="checkbox" id="mesma_senha"  >

                        <br /> <br>
                        <div id="div_senha">

                            <div class="form-group">
                                {!! Form::label('password', 'Nova Senha *'); !!}

                                {!! Form::password('password', array('class' => 'form-control')); !!}
                            </div>

                            <div class="form-group">
                                {!! Form::label('password_confirmation', 'Confirme a nova senha *'); !!}

                                {!! Form::password('password_confirmation', array('class' => 'form-control')); !!}
                            </div>
                        </div>

                    <div class="form-group">
                        {!! Form::submit('Salvar', array('class' => 'btn btn-primary')); !!}
                        <a class="btn btn-danger delete" href="{{ url('user')}}">Voltar</a>

                        {!! Form::reset('Limpar', array('class' => 'btn btn-warning')); !!}
                    </div>

                    {!! Form::close() !!}
                </div>
            </div>
    </div>
        <script type="text/javascript" src="{{asset('assets/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js')}}"></script>
        <script type="text/javascript">
            $('#mesma_senha').click(function(){
                var tamanho = $('#mesma_senha:checked').length;
                if (tamanho == 0){
                    $("#div_senha").show();
                }else{
                    $("#div_senha").hide();
                }
                //alert($('#mesma_senha:checked').length);

            });
            $(document).ready(function(){
               //
                $("#div_senha").hide();

                $("#cpf").inputmask("999.999.999-99");
               //
            });
        </script>
@endsection
