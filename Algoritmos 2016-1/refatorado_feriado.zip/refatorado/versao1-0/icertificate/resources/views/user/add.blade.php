@extends('dashboard.'.Session::get('layout'))
<style>
    .red{
        color:red;
    }
</style>
@section('context')
        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">Cadastrar Novo Usuario</div>
                <div class="panel-body">
                	{!! Form::open(array('url' => 'user/add', 'method' => 'post')) !!}

                        <p>Campos com <span class="red"> * </span>são obrigatorios</p>
                        <div class="form-group">
                            {!! Form::label('nome', 'Nome *'); !!}

							{!! Form::text('nome', null, array('class' => 'form-control')); !!}
                        </div>
                        <div class="form-group">
                            {!! Form::label('cpf', 'Cpf *'); !!}

							{!! Form::text('cpf', null, array('class' => 'form-control')); !!}
                        </div>
                        <div class="form-group">
                            {!! Form::label('rg', 'RG *'); !!}

							{!! Form::text('rg', null, array('class' => 'form-control')); !!}
                        </div>

                        <div class="form-group">
                            {!! Form::label('matricula', 'Matricula *'); !!}

							{!! Form::text('matricula', null, array('class' => 'form-control')); !!}
                        </div>

                        <div class ="form-group">
                        	{!! Form::label('tipo', 'Tipo de Usuario *'); !!}

							{!! Form::select('tipo', array('C' => 'Coordenador', 'G' => 'Gerente'), null, array('class' => 'form-control')); !!}

                        </div>

                        <div class="form-group">
                            {!! Form::label('email', 'Email *'); !!}

							{!! Form::text('email', null, array('class' => 'form-control', 'required' => true)); !!}
                        </div>

                        <div class="form-group">
                            {!! Form::label('password', 'Senha *'); !!}

							{!! Form::password('password', array('class' => 'form-control')); !!}
                        </div>

                        <div class="form-group">
                            {!! Form::label('password_confirmation', 'Confirme a senha *'); !!}

							{!! Form::password('password_confirmation', array('class' => 'form-control')); !!}
                        </div>

                        <div class="form-group">
                            {!! Form::submit('Salvar', array('class' => 'btn btn-primary')); !!}

                            <a class="btn btn-danger delete" href="{{ url('user')}}">Voltar</a>

                            {!! Form::reset('Limpar', array('class' => 'btn btn-warning')); !!}

                        </div>

                    {!! Form::close() !!}
                </div>
            </div>
    </div>



        <script type="text/javascript" src="{{asset('assets/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js')}}"></script>


        <script type="text/javascript">
            $(document).ready(function(){
               //
                $("#cpf").inputmask("999.999.999-99");
               //
            });
        </script>
@endsection
