@extends('dashboard.'.Session::get('layout'))

@section('context')
    <div class="col-md-9">
        <h2>Detalhes do Usuario</h2>

        <p>Matricula: {{$user->matricula}}</p>
        <p>Nome: {{$user->nome}}</p>
        <p>Email: {{$user->email}}</p>
        <p>Rg: {{$user->rg}}</p>
        <p>Cpf: {{$user->cpf}}</p>
        <p>Tipo de Usuario: {{$user->tipo}}</p>
    </div>
    <a class="btn btn-primary" href="{{ url('user')}}"style="margin-right:10px">Voltar</a>

@endsection