@extends('layouts.main')

@section('menu_options')
@endsection

@section('content')
<div class="container">
	<div class="row">
		<h2 class="text-center">Pagina nao encontrada, tente novamente.</h2>
	</div>
</div>
@endsection