@extends('layouts.guest')

@section('menu_options')
@endsection
<style>
    .red{
        color:red;
    }
</style>
@section('content')

    {!! Form::open(array('url' => 'participante/edit/'.$p->id, 'method' => 'put')) !!}
       <p>Campos com <span class="red"> * </span>são obrigatorios</p>

       <div class="form-group">
        	{!! Form::label('matricula', 'Matricula'); !!}

			{!! Form::text('matricula', $p->matricula, array('class' => 'form-control')); !!}
        </div>

        <div class="form-group">
            {!! Form::label('nome', 'Nome'); !!}

			{!! Form::text('nome', $p->nome, array('class' => 'form-control', 'required' => true)); !!}
        </div>

        <div class="form-group">
        	{!! Form::label('cpf', 'Cpf'); !!}

			{!! Form::text('cpf', $p->cpf, array('class' => 'form-control')); !!}
        </div>

        <div class="form-group">
            {!! Form::label('email', 'Email'); !!}

			{!! Form::text('email', $p->email, array('class' => 'form-control', 'required' => true)); !!}
        </div>

        <div class="form-group">
            {!! Form::submit('Salvar', array('class' => 'btn btn-primary')); !!}
            <a class="btn btn-danger delete" href="{{ url('user')}}">Voltar</a>

            {!! Form::reset('Limpar', array('class' => 'btn btn-warning')); !!}
        </div>
    {!! Form::close() !!}
    <script type="text/javascript">
        $(document).ready(function(){
           //
            $("#cpf").inputmask("999.999.999-99");
           //
        });
    </script>
@endsection