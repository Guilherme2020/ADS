@extends('layouts.guest')

@section('menu_options')
@endsection
<style>
    .red{
        color:red;
    }
</style>
@section('content')

    <h2>Cadastre-se no evento: {{$evento->nome}}</h2>

    {!! Form::open(array('url' => 'evento/cadastro/'.$evento->slug, 'method' => 'post')) !!}

        <p>Campos com <span class="red"> * </span>são obrigatorios</p>
        <div class="form-group">
        	{!! Form::label('matricula', 'Matricula Institucional '); !!}

			{!! Form::text('matricula', null, array('class' => 'form-control')); !!}
        </div>

        <div class="form-group">
            {!! Form::label('nome', 'Nome *'); !!}

			{!! Form::text('nome', null, array('class' => 'form-control', 'required' => true)); !!}
        </div>

        <div class="form-group">
        	{!! Form::label('cpf', 'Cpf *'); !!}

			{!! Form::text('cpf', null, array('class' => 'form-control')); !!}
        </div>

        <div class="form-group">
            {!! Form::label('email', 'Email *'); !!}

			{!! Form::text('email', null, array('class' => 'form-control', 'required' => true)); !!}
        </div>

        <div class="form-group">
            {!! Form::submit('Enviar Inscrição ', array('class' => 'btn btn-primary')); !!}

			{!! Form::reset('Limpar', array('class' => 'btn btn-warning')); !!}
        </div>
    {!! Form::close() !!}




    <script type="text/javascript" src="{{asset('assets/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js')}}"></script>


    <script type="text/javascript">
        $(document).ready(function(){
           //
            $("#cpf").inputmask("999.999.999-99");
           //
        });
    </script>
@endsection