@extends('layouts.main')

@section('menu_options')
@endsection

@section('content')
<div class="container">
	<div class="row">
		<div class="col-md-offset-3 col-md-6 col-md-offset-3">
	        <div class="panel panel-default">
	            <div class="panel-heading">Area de Login</div>
	            <div class="panel-body">
					{!! Form::open(array('url' => 'login', 'method' => 'post')) !!}

					<div class="form-group">
					{!! Form::label('matricula', 'Matricula'); !!}

					{!! Form::text('matricula', null, array('class' => 'form-control')); !!}
					</div>

					<div class="form-group">
					{!! Form::label('password', 'Senha'); !!}

					{!! Form::password('password', array('class' => 'form-control')); !!}
					</div>

					<div class="form-group">
					{!! Form::submit('Login', array('class' => 'btn btn-primary')); !!}

					{!! Form::reset('Limpar', array('class' => 'btn btn-warning')); !!}
					</div>

					{!! Form::close() !!}
				</div>
			</div>
		</div>
		<!---->
	</div>
</div>
@endsection