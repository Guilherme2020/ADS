@extends('dashboard.'.Session::get('layout'))

@section('context')
<h2 class="text-center">Seja bem vindo(a), {{ Auth::user()->nome }}</h2>
@endsection