<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>iCertificate</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="{{ asset('assets/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/bootstrap/dist/css/bootstrap.css') }}" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <link href="{{ asset('assets/bootply_custom/styles.css') }}" rel="stylesheet">
    <!-- script references -->
    <script src="{{ asset('assets/jquery/dist/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/bootstrap/dist/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('assets/bootply_custom/scripts.js') }}"></script>
</head>
<body>
<!-- header -->
<div id="top-nav" class="navbar navbar-inverse navbar-static-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="{{ Auth::user() ? url('/dashboard') : '#' }}">iCertificate</a>
        </div>

        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
                @yield('menu_options')
            </ul>
        </div>
    </div>
    <!-- /container -->
</div>
<!-- /Header -->

<!--END HEAD-->
<div class="container-fluid">
    <div class="col-md-12">
        <!--ERRORS-->
        @if (count($errors) > 0)
            <div class="alert alert-danger">
                <strong>Opa!</strong> Algum(ns) problema(s) nos dados:<br><br>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif
                    <!--FIM ERRORS-->

            <!--MENSAGENS-->
            @if(isset($message))
                <div class="alert alert-success">
                    <strong>{{ $message }}</strong>
                </div>
                @endif
                        <!--FIM MENSAGENS-->
                @yield('content')
    </div>
</div>
<!--<footer class="text-center">iCertificate IFPI</footer>-->
<div class="modal" id="addWidgetModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title">Add Widget</h4>
            </div>
            <div class="modal-body">
                <p>Add a widget stuff here..</p>
            </div>
            <div class="modal-footer">
                <a href="#" data-dismiss="modal" class="btn">Close</a>
                <a href="#" class="btn btn-primary">Save changes</a>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dalog -->
</div>
<!-- /.modal -->
<footer class="footer">
    <div class="container">
        <p>© Sistema Icertificate todos direitos Reservados ao IFPI.</p>
    </div>
</footer>
</body>
</html>
