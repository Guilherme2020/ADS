<p>Olá <strong>{{ $username }}</strong>, tudo bem?</p>

<p>Obrigado pela participação no evento: <strong>{{ $nome_evento }}</strong>!</p>

<p>Segue em anexo o seu certificado!</p>

<p>Abraços!</p>