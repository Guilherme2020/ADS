<p>Olá <strong>{{ $u->username }}</strong>, tudo bem?</p>

<p>Você acaba de ser cadastrado na plataforma de certificados!</p>

<p>Segue abaixo seus dados de login:</p>

<p>Nome de usuario: Sua Matricula(<strong>{{ $u->matricula }}</strong>)</p>
<p>Senha: <strong>{{ $u->senha }}</strong></p>
<p></p>

<p>Abraços!</p>