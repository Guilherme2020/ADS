@extends('dashboard.'.Session::get('layout'))
@section('context')
    <div class="col-md-9">
        <div class="panel panel-default">
            <div class="panel-heading">Definição de Configurações</div>
            <div class="panel-body">
            {!! Form::open(array('url' => 'configuracao/add', 'method' => 'post')) !!}
                    <div class="form-group">
                    	{!! Form::label('instituicao', 'Instituicao'); !!}

						{!! Form::text('instituicao', $c->instituicao, array('class' => 'form-control')); !!}
                    </div>
                    
                    <div class="form-group">
                        {!! Form::label('cidade', 'Cidade'); !!}

                        {!! Form::text('cidade', $c->cidade, array('class' => 'form-control')); !!}
                    </div>

                    <div class="form-group">
                        {!! Form::label('estado', 'Estado'); !!}

                        {!! Form::text('estado', $c->estado, array('class' => 'form-control')); !!}
                    </div>

                    <div class="form-group">
                        {!! Form::label('nome_superior', 'Nome do Superior'); !!}

                        {!! Form::text('nome_superior', $c->nome_superior, array('class' => 'form-control')); !!}
                    </div>

                    <div class="form-group">
                        {!! Form::label('cargo_superior', 'Cargo do Superior'); !!}

                        {!! Form::text('cargo_superior', $c->cargo_superior, array('class' => 'form-control')); !!}
                    </div>

                    <div class="form-group">
                        {!! Form::label('nome_responsavel', 'Nome do Responsavel'); !!}

                        {!! Form::text('nome_responsavel', $c->nome_responsavel, array('class' => 'form-control')); !!}
                    </div>

                    <div class="form-group">
                        {!! Form::label('cargo_responsavel', 'Cargo do Responsavel'); !!}

                        {!! Form::text('cargo_responsavel', $c->cargo_responsavel, array('class' => 'form-control')); !!}
                    </div>

                    <div class="form-group">
                        {!! Form::label('setor', 'Setor Responsavel'); !!}

                        {!! Form::text('setor', $c->setor, array('class' => 'form-control')); !!}
                    </div>

                    <div class="form-group">
                        {!! Form::submit('Salvar', array('class' => 'btn btn-primary')); !!}

						{!! Form::reset('Limpar', array('class' => 'btn btn-warning')); !!}
                    </div>

                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection
