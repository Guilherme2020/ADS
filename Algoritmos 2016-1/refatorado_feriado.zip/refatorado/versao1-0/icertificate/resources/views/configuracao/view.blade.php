@extends('dashboard.'.Session::get('layout'))

@section('context')
<div class="col-md-9">
    <h2>Definições de Configurações</h2>
    
    <span>
    	<p><strong>Instituição:</strong> {{ $c->instituicao }}</p>
    	<p><strong>Cidade:</strong> {{ $c->cidade }}</p>
    	<p><strong>Estado:</strong> {{ $c->estado }}</p>
    	<p><strong>Nome do Superior:</strong> {{ $c->nome_superior }}</p>
    	<p><strong>Cargo do Superior:</strong> {{ $c->cargo_superior }}</p>
    	<p><strong>Nome do Responsavel:</strong> {{ $c->nome_responsavel }}</p>
    	<p><strong>Cargo do Responsavel:</strong> {{ $c->cargo_responsavel }}</p>
    	<p><strong>Setor Responsavel:</strong> {{ $c->setor }}</p>
    </span>
</div>
@endsection